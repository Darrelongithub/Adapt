import numpy as np, potrace, glob, os
from PIL import Image, ImageFilter
def vectorize(path, out, scale=2, thresh=0.5):
    im=Image.open(path).convert("RGB")
    a=np.asarray(im).astype(float)
    # background colour = median of the image (paper); ink = pixels far darker/bluer than paper
    bg=np.median(a.reshape(-1,3),axis=0)
    lum=a.mean(axis=2); bglum=bg.mean()
    # estimate local background with a heavy blur to cope with gradients / paper noise
    blur=np.asarray(im.convert("L").filter(ImageFilter.GaussianBlur(25))).astype(float)
    diff=blur-np.asarray(im.convert("L")).astype(float)
    ink=np.clip(diff/ max(1.0,np.percentile(diff,99.5)),0,1)
    big=Image.fromarray((ink*255).astype('uint8')).resize((im.width*scale,im.height*scale),Image.LANCZOS)
    arr=np.asarray(big)>(255*thresh*0.55)
    m=8*scale; arr[:m,:]=False; arr[-m:,:]=False; arr[:,:m]=False; arr[:,-m:]=False
    bm=potrace.Bitmap(~arr)
    plist=bm.trace(turdsize=6,turnpolicy=potrace.POTRACE_TURNPOLICY_MINORITY,alphamax=1.1,opttolerance=0.4)
    parts=[]
    for curve in plist:
        fs=curve.start_point; d=f"M{fs.x/scale:.1f},{fs.y/scale:.1f}"
        for seg in curve.segments:
            if seg.is_corner:
                d+=f"L{seg.c.x/scale:.1f},{seg.c.y/scale:.1f}L{seg.end_point.x/scale:.1f},{seg.end_point.y/scale:.1f}"
            else:
                d+=f"C{seg.c1.x/scale:.1f},{seg.c1.y/scale:.1f} {seg.c2.x/scale:.1f},{seg.c2.y/scale:.1f} {seg.end_point.x/scale:.1f},{seg.end_point.y/scale:.1f}"
        parts.append(d+"Z")
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {im.width} {im.height}" aria-hidden="true"><path fill="currentColor" fill-rule="evenodd" d="{"".join(parts)}"/></svg>'
    open(out,"w").write(svg); return len(svg)
for f in sorted(glob.glob("src/*.jpg")):
    n=os.path.basename(f)[:-4]
    print(n, vectorize(f,f"art/{n}.svg"), "bytes")
