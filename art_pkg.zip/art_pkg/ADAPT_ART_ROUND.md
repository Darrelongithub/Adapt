# ADAPT — Art & UI polish round (run AFTER the Round 4 no-art fixes are merged)

Same ground rules as before: own branch `art/<letter>`, edit only files you own, never weaken tests, verify in a real browser (Chromium at /opt/pw-browsers/chromium; never `playwright install`), console-only API config, no learner-facing mention of AI 1/2/3, models, providers. Commit trailer: `Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>`. Tracks P, Q run in parallel; track R last.

## Owner's art direction (final)
Blue line art on the existing beige. No photos, no filled/solid illustrations, no hand-drawn doodle art. The owner supplied six reference pieces; they are vectorised in `art/*.svg` (transparent, `fill="currentColor"`, recolourable): `topo.svg` (topographic pattern), `brain.svg` (side-view brain), `classroom.svg` (faceless teacher + students), `study.svg` (faceless student writing at a desk with laptop), `gears.svg`, `flower.svg` (corner floral). `art/vec.py` regenerates them from `src/*.jpg` (needs `pip install potracer pillow numpy`); keep it in `scripts/art/`. Snapshots of the target look are in `snapshots/` (`*-AFTER.png`; consent and learn are closest to final).

## THE placement rule (owner's words, formalised)
**The pattern lives in the page background behind the cards — it shows only in the empty space between cards, never inside a content card.** Cards keep their solid `--panel` fill (they already do: `bg-[var(--panel)]`). Big illustrations (classroom, study, brain, gears, flower) sit only in empty areas, on a soft beige "island" (radial gradient to transparent) so the pattern fades out behind them. Never overlap text, inputs, option cards or buttons.

Implementation notes (learned from the mock):
- Put the pattern on a fixed layer **behind** content: `position:fixed; inset:0 0 0 <sidebar width>; z-index:-1` (or on the main wrapper's `::before`). In the mock it was above the cards, which is why it showed through them — do not copy that.
- Tile the topo pattern at its native size (`background-size: ~520px auto; repeat`), `opacity` ≈ 0.10–0.12, colour from a token `--art-ink` (brand blue); dark-mode variant. Scaling it up to the full viewport makes the strokes thick and loud — don't.
- Inline SVG for the hero illustrations, `currentColor`, `aria-hidden`, `pointer-events:none`; line weight must look the same on every page (don't scale pieces unevenly).
- Mobile (<640px): pattern only (even fainter); hero illustrations hidden except one small cropped piece on the consent screen.
- Total added weight < 150 KB gzipped (the traced SVGs are big: simplify with `svgo`/path simplification, or serve the 6 art files as static assets with long cache headers, not inlined in every bundle).

## TRACK P — Backgrounds and hero art (owns `frontend/src/components/art/*`, global layout shells, page backgrounds)
Page map (one hero piece per page, at most):
- consent / sign-in / welcome: corner floral (`flower.svg`, left edge, ~360px) + topo behind the card.
- first-run mind check (format pick and the 13 questions): brain in the right empty area (~230px) + topo.
- journey: study scene bottom-right in the empty area below the step cards + topo.
- learn / first lesson (empty state before a lesson exists): classroom scene centred under the topic box (~640px); once a lesson is on screen the scene shrinks to a small version in the free gutter on wide screens or disappears.
- settings: gears bottom-right BELOW the last card (never over "This instance") + topo.
- home: study scene in a free corner (below the fold is fine) + topo.
- review, progress, proposals, evidence, voice, subject round, contrast, games: topo only, plus a small monoline icon per page header (same stroke weight as the sidebar icons).
- empty states ("No answers yet", "Nothing due yet", "Nothing waiting"): topo is enough; do not add art inside cards.

## TRACK Q — Icons on buttons and navigation (owns button components and icon set)
Owner's request: the home-page buttons get icons. Build a small monoline icon set (24×24 grid, 1.8px stroke, round caps) as React components and use them on: every primary/secondary button on Home (Start/Resume assessment → play, Your path → route/signpost, Personalise your setup → sliders/gear, View all progress → bars, Review what is due → clock, Review proposed changes → speech-bubble/pen), the sidebar items (replace the numbers 02/03/04 with icons), game cards (Vault lights → key, Spy codewords → magnifier, Crack the machine → gears, Bet your coins → coin, The locked box → box), and subject cards (maths, language, science, history). Icons are `aria-hidden`; labels stay as text; buttons keep ≥44px targets and focus rings. The mock added icons by injection; the first-pass "Your path" icon read as a squiggle — design a proper route/signpost icon.

## TRACK R — Integrate and verify (last)
Merge P and Q. Playwright screenshots of EVERY route at 1280×800, 1024×768 and 390×844, light and dark if dark mode exists. Automated checks: (1) no art element's bounding box intersects any `input, button, a, p, h1–h6, label, [role=radio], [role=button]`; (2) the pattern layer has `z-index` below every card (test by sampling a pixel inside a card: it must equal the panel colour); (3) art nodes are `aria-hidden` with `pointer-events:none`; (4) page weight/LCP did not regress beyond the stated budget; (5) the banned-phrase crawl still passes. Report with screenshots and anything that still looks off.
