# ADAPT — Adaptive AI Learning That Evolves With Every Child

A full-stack demo of the ADAPT spec, built on Next.js (App Router) +
Drizzle ORM + PostgreSQL, themed in premium beige & blue.

## What's inside

- **Onboarding → diagnostic assessment** across 5 question modalities
  (mcq, numeric, worked example, visual/diagram, teach-back).
- **Two Gemini-powered AIs**: AI 1 (Learning Intelligence) forms
  hypotheses from telemetry; AI 2 (Educational Intelligence) is the tutor
  the student talks to. See `docs/MASTER_PROMPTS.md` for every prompt.
- **The Approval Gate** — AI 1 never changes strategy silently. Every
  proposal is shown with evidence and the exact script, and only applied
  after the student approves it (`/dashboard`).
- **Adaptive practice** with a simplified Bayesian Knowledge Tracing
  engine that adjusts difficulty per topic in real time (`/practice`).
- **Real-time voice tutor** using the browser's native speech recognition
  and speech synthesis — zero paid APIs, runs locally (`/tutor`).
- **Open knowledge layer** — OpenAlex, arXiv, Open Library, and (if you
  add a key) YouTube, curated by AI 2 for the learner's level.
- **Full dashboard** — mastery per topic, modality performance, approval
  history, telemetry timeline, and spaced-repetition retention checks.

## Environment variables (all optional)

The app runs completely out of the box with deterministic local fallbacks.
Add these to `.env` to light up real Gemini calls:

```
GEMINI_API_KEY=your_free_google_ai_studio_key
GEMINI_MODEL=gemini-2.0-flash
YOUTUBE_API_KEY=your_youtube_data_api_key   # optional, resource layer only
```

Get a free Gemini key at https://aistudio.google.com/apikey.

## Running locally

```bash
npm install
npx drizzle-kit push   # creates tables from src/db/schema.ts
npm run dev
```

Open http://localhost:3000, click **Start demo**, and walk through
onboarding → diagnostic → practice → voice tutor → dashboard.

## Project structure

```
src/app/            pages (onboarding, diagnostic, practice, tutor, dashboard)
src/app/api/        API routes (students, diagnostic, quiz, ai1, ai2, ...)
src/lib/prompts.ts  master prompts for AI 1 / AI 2 (source of truth)
src/lib/gemini.ts   Gemini REST client with graceful fallback
src/lib/mastery.ts  BKT mastery + modality-affinity engine
src/lib/resources.ts OpenAlex/arXiv/Open Library/YouTube client
src/db/schema.ts    Drizzle schema (students, profiles, telemetry, ...)
docs/MASTER_PROMPTS.md  human-readable copy of every master prompt
```
