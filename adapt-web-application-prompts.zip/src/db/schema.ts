import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
  real,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ---------------------------------------------------------------------------
// Students & learner profile (AI 1 writes, AI 2 reads)
// ---------------------------------------------------------------------------

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  gradeLevel: text("grade_level").default(""),
  subject: text("subject").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const learnerProfiles = pgTable(
  "learner_profiles",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    // topicId -> { mastery: 0..1, attempts, correct, lastPracticed }
    masteryJson: jsonb("mastery_json").notNull().default({}),
    // modality key -> { attempts, correct, avgMs }
    modalityJson: jsonb("modality_json").notNull().default({}),
    strengthsJson: jsonb("strengths_json").notNull().default([]),
    gapsJson: jsonb("gaps_json").notNull().default([]),
    strategyJson: jsonb("strategy_json").notNull().default({
      explanationStyle: "balanced",
      workedExampleRatio: 0.3,
      hintAggressiveness: "standard",
      preferredPace: "standard",
    }),
    narrative: text("narrative").default(""),
    updatedAt: timestamp("updated_at").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("learner_profiles_student_idx").on(table.studentId)],
);

// ---------------------------------------------------------------------------
// Curriculum content: subjects -> topics -> questions
// ---------------------------------------------------------------------------

export const topics = pgTable(
  "topics",
  {
    id: serial("id").primaryKey(),
    subject: text("subject").notNull(),
    slug: text("slug").notNull(),
    title: text("title").notNull(),
    description: text("description").default(""),
    orderIndex: integer("order_index").default(0),
  },
  (table) => [uniqueIndex("topics_slug_idx").on(table.slug)],
);

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  topicId: integer("topic_id")
    .notNull()
    .references(() => topics.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // diagnostic | practice | retention
  type: text("type").notNull(), // mcq | numeric | teach_back | worked_example | visual
  prompt: text("prompt").notNull(),
  payloadJson: jsonb("payload_json").notNull().default({}),
  difficulty: integer("difficulty").default(2),
});

// ---------------------------------------------------------------------------
// The Approval Gate: hypotheses AI 1 proposes before changing strategy
// ---------------------------------------------------------------------------

export const adaptationProposals = pgTable("adaptation_proposals", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  evidenceJson: jsonb("evidence_json").notNull().default([]),
  currentStrategy: text("current_strategy").notNull(),
  proposedStrategy: text("proposed_strategy").notNull(),
  proposedPatchJson: jsonb("proposed_patch_json").notNull().default({}),
  scriptText: text("script_text").notNull(),
  status: text("status").notNull().default("pending"), // pending | approved | rejected
  studentNote: text("student_note").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});

// ---------------------------------------------------------------------------
// Telemetry: every learning event
// ---------------------------------------------------------------------------

export const telemetryEvents = pgTable("telemetry_events", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  sessionId: text("session_id").notNull(),
  eventType: text("event_type").notNull(),
  payloadJson: jsonb("payload_json").notNull().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// Quiz / diagnostic attempts
// ---------------------------------------------------------------------------

export const quizAttempts = pgTable("quiz_attempts", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  questionId: integer("question_id")
    .notNull()
    .references(() => questions.id, { onDelete: "cascade" }),
  kind: text("kind").notNull(), // diagnostic | practice | retention
  answerHistoryJson: jsonb("answer_history_json").notNull().default([]),
  finalAnswer: text("final_answer").default(""),
  correct: boolean("correct").default(false),
  score: real("score").default(0),
  timeSpentMs: integer("time_spent_ms").default(0),
  hintsUsed: integer("hints_used").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// Chat / voice conversation log (AI 2, tutor)
// ---------------------------------------------------------------------------

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  sessionId: text("session_id").notNull(),
  role: text("role").notNull(), // user | assistant
  aiSystem: text("ai_system").default("ai2"), // ai1 | ai2
  content: text("content").notNull(),
  modality: text("modality").default("text"), // text | voice
  resourcesJson: jsonb("resources_json").default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// Cached external educational resources
// ---------------------------------------------------------------------------

export const resourceCache = pgTable("resource_cache", {
  id: serial("id").primaryKey(),
  topicId: integer("topic_id")
    .notNull()
    .references(() => topics.id, { onDelete: "cascade" }),
  source: text("source").notNull(), // openalex | arxiv | openlibrary | youtube
  title: text("title").notNull(),
  url: text("url").notNull(),
  metadataJson: jsonb("metadata_json").notNull().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ---------------------------------------------------------------------------
// Retention / spaced-repetition checks
// ---------------------------------------------------------------------------

export const retentionChecks = pgTable("retention_checks", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => students.id, { onDelete: "cascade" }),
  topicId: integer("topic_id")
    .notNull()
    .references(() => topics.id, { onDelete: "cascade" }),
  dueAt: timestamp("due_at").notNull(),
  completedAt: timestamp("completed_at"),
  resultJson: jsonb("result_json").default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
