import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Nav } from "@/components/Nav";
import "./globals.css";

export const metadata: Metadata = {
  title: "ADAPT — Adaptive AI Learning That Evolves With Every Child",
  description:
    "A personalized learning system that studies how a student learns, builds evidence-based understanding, and only changes strategy with the student's approval.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-beige-50 text-ink-900 antialiased">
        <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_20%_-10%,rgba(54,111,224,0.12),transparent_45%),radial-gradient(circle_at_85%_10%,rgba(223,200,155,0.35),transparent_40%)]" />
        <Nav />
        {children}
      </body>
    </html>
  );
}
