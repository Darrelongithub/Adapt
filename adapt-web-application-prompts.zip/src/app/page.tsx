import Link from "next/link";
import { Badge, Button, Card, SectionLabel } from "@/components/ui";

const PILLARS = [
  {
    title: "AI 1 · Learning Intelligence",
    body: "Cognitive-science reasoning (BKT, retrieval practice, spaced repetition, worked-example effect). Forms hypotheses from telemetry, never changes strategy without your approval.",
  },
  {
    title: "AI 2 · Educational Intelligence",
    body: "The tutor you actually talk to — by text or by voice. Reads the live learner profile and adapts explanations, pacing, hints, and resources in real time.",
  },
  {
    title: "The Approval Gate",
    body: "Every persistent strategy change is proposed with evidence, in plain language, and only applied once the student says yes.",
  },
];

const FEATURES = [
  { n: "01", t: "Onboarding & diagnostic", d: "Text, visual, worked-example, interactive, and teach-back questions build the first learner profile." },
  { n: "02", t: "Two Gemini-powered AIs", d: "A learning-science brain and a teaching brain, sharing one evolving learner profile." },
  { n: "03", t: "Shared memory", d: "Every hypothesis, approval, and telemetry event is persisted — AI 1 writes, AI 2 reads." },
  { n: "04", t: "Deep telemetry", d: "Timing, answer changes, hints, retries, and full event sequences — nothing is thrown away." },
  { n: "05", t: "Personalized engine", d: "Adaptive difficulty via Bayesian Knowledge Tracing, modality-affinity tracking, and gap remediation." },
  { n: "06", t: "Approval-gated adaptation", d: "\u201cHey, we noticed you did A, B, C, D… do you want to change X to Y?\u201d — always opt-in." },
  { n: "07", t: "Real-time voice tutor", d: "Natural back-and-forth conversation with interruption support, running locally in the browser." },
  { n: "08", t: "Speech in & out", d: "Local speech recognition and speech synthesis — zero paid voice APIs." },
  { n: "09", t: "Open knowledge access", d: "OpenAlex, arXiv, Open Library, and YouTube — curated by AI 2 for the learner's level." },
  { n: "10", t: "Privacy by design", d: "Postgres storage, HTTPS in transit, minimal payloads sent to the model." },
  { n: "11", t: "Full dashboard", d: "Mastery, modality performance, adaptation history, telemetry timeline, and retention checks." },
  { n: "12", t: "Zero paid cost", d: "Gemini free tier, free resource APIs, and browser-native voice. Nothing to pay for." },
];

export default function HomePage() {
  return (
    <main>
      <section className="mx-auto grid max-w-6xl gap-10 px-6 pb-16 pt-16 md:grid-cols-[1.2fr_1fr] md:pt-24">
        <div>
          <Badge tone="beige">Adaptive AI Learning Demo</Badge>
          <h1 className="mt-5 font-display text-[clamp(2.4rem,5.5vw,4rem)] font-semibold leading-[1.05] text-ink-950">
            Learning should <span className="text-sky-600">adapt to the learner.</span>
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-600">
            ADAPT studies how a student actually interacts with material, builds an evidence-based
            understanding of them, and personalizes their journey — but it never changes a strategy
            behind their back. Every adaptation is proposed, explained, and approved first.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/onboarding">
              <Button variant="secondary">Start the demo →</Button>
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost">View a live dashboard</Button>
            </Link>
          </div>
          <div className="mt-10 grid grid-cols-3 gap-4 text-center">
            {[
              ["$0", "cost to run"],
              ["2", "cooperating Gemini AIs"],
              ["100%", "opt-in adaptation"],
            ].map(([n, l]) => (
              <div key={l} className="rounded-2xl border border-beige-200 bg-white/70 px-3 py-4">
                <p className="font-display text-2xl font-semibold text-ink-900">{n}</p>
                <p className="mt-1 text-xs uppercase tracking-wide text-ink-500">{l}</p>
              </div>
            ))}
          </div>
        </div>

        <Card className="p-6">
          <SectionLabel>The approval gate — live example</SectionLabel>
          <div className="mt-4 space-y-3 rounded-2xl bg-ink-900 p-5 font-mono text-[13px] leading-relaxed text-beige-100">
            <p className="text-sky-300">AI 1 → observes telemetry</p>
            <p>• re-answered question 3 four times</p>
            <p>• 2.4x slower on text-only explanations</p>
            <p>• scored 40% lower without a worked example</p>
            <p>• this pattern repeated 3 sessions in a row</p>
            <p className="pt-2 text-beige-300">
              "Hey, we noticed you did these four things. Based on what we&rsquo;ve observed, we want to
              change <span className="text-sky-300">mostly text explanations</span> to{" "}
              <span className="text-sky-300">leading with worked examples</span>. Do you want to
              continue, and is there anything else you&rsquo;d like to add?"
            </p>
            <div className="flex gap-2 pt-2">
              <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-emerald-300">Approve</span>
              <span className="rounded-full bg-rose-500/20 px-3 py-1 text-rose-300">Not yet</span>
            </div>
          </div>
        </Card>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-10">
        <div className="grid gap-5 md:grid-cols-3">
          {PILLARS.map((p) => (
            <Card key={p.title} className="p-6">
              <h3 className="font-display text-lg font-semibold text-ink-900">{p.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-600">{p.body}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-14">
        <SectionLabel>The full spec, shipped</SectionLabel>
        <h2 className="mt-2 font-display text-3xl font-semibold text-ink-950">Twelve sections, zero cost.</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.n} className="rounded-2xl border border-beige-200 bg-white/60 p-5">
              <span className="font-display text-sm font-semibold text-sky-600">{f.n}</span>
              <h4 className="mt-1 font-semibold text-ink-900">{f.t}</h4>
              <p className="mt-1.5 text-sm text-ink-600">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-20">
        <Card className="flex flex-col items-start justify-between gap-6 p-8 md:flex-row md:items-center">
          <div>
            <h3 className="font-display text-2xl font-semibold text-ink-900">Ready to see it run?</h3>
            <p className="mt-2 max-w-lg text-sm text-ink-600">
              Onboard a learner, take the diagnostic, practice a few adaptive questions, approve a
              strategy change, and watch the dashboard update — all in one browser tab.
            </p>
          </div>
          <Link href="/onboarding">
            <Button variant="primary">Begin onboarding →</Button>
          </Link>
        </Card>
      </section>
    </main>
  );
}
