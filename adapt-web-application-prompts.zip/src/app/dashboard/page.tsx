"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Badge, Button, Card, ProgressBar, SectionLabel } from "@/components/ui";
import { useStudentSession } from "@/lib/useStudent";

type DashboardData = {
  student: { id: number; name: string; subject: string };
  profile: { narrative: string; strategyJson: Record<string, unknown>; strengthsJson: string[]; gapsJson: string[] };
  topics: Array<{ id: number; title: string; mastery: number; attempts: number; correct: number }>;
  modalityMap: Record<string, { attempts: number; correct: number; avgMs: number }>;
  proposals: Array<{
    id: number;
    title: string;
    evidenceJson: string[];
    currentStrategy: string;
    proposedStrategy: string;
    scriptText: string;
    status: string;
    studentNote: string;
    createdAt: string;
  }>;
  telemetry: Array<{ id: number; eventType: string; payloadJson: Record<string, unknown>; createdAt: string }>;
  retention: Array<{ id: number; topicId: number; topicTitle: string; dueAt: string; completedAt: string | null }>;
  stats: { totalAttempts: number; totalCorrect: number };
};

const MODALITY_LABEL: Record<string, string> = {
  mcq: "Multiple choice",
  numeric: "Numeric",
  teach_back: "Teach-back",
  worked_example: "Worked example",
  visual: "Visual",
};

export default function DashboardPage() {
  const router = useRouter();
  const { student, sessionId, ready } = useStudentSession();
  const [data, setData] = useState<DashboardData | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [note, setNote] = useState("");
  const [resolving, setResolving] = useState(false);
  const [retentionBusy, setRetentionBusy] = useState<number | null>(null);
  const [retentionQuestion, setRetentionQuestion] = useState<Record<number, string>>({});

  const load = useCallback(() => {
    if (!student) return;
    fetch(`/api/dashboard?studentId=${student.studentId}`)
      .then((r) => r.json())
      .then(setData);
  }, [student]);

  useEffect(() => {
    if (!ready) return;
    if (!student) {
      router.push("/onboarding");
      return;
    }
    load();
  }, [ready, student, router, load]);

  async function runAnalysis() {
    if (!student) return;
    setAnalyzing(true);
    await fetch("/api/ai1/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentId: student.studentId }),
    });
    setAnalyzing(false);
    load();
  }

  async function resolveProposal(id: number, action: "approve" | "reject") {
    setResolving(true);
    await fetch(`/api/adaptations/${id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, note, sessionId }),
    });
    setNote("");
    setResolving(false);
    load();
  }

  async function generateRetention(id: number) {
    setRetentionBusy(id);
    const res = await fetch("/api/retention", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ checkId: id, action: "generate" }),
    });
    const resData = await res.json();
    setRetentionQuestion((prev) => ({ ...prev, [id]: resData.generated?.question ?? "" }));
    setRetentionBusy(null);
  }

  async function completeRetention(id: number) {
    setRetentionBusy(id);
    await fetch("/api/retention", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ checkId: id, action: "complete", answer: "reviewed in demo" }),
    });
    setRetentionBusy(null);
    load();
  }

  if (!ready || !student || !data) {
    return <main className="mx-auto max-w-5xl px-6 py-24 text-center text-ink-500">Loading dashboard…</main>;
  }

  const pending = data.proposals.find((p) => p.status === "pending");
  const resolvedProposals = data.proposals.filter((p) => p.status !== "pending");
  const accuracy = data.stats.totalAttempts ? Math.round((data.stats.totalCorrect / data.stats.totalAttempts) * 100) : 0;

  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <SectionLabel>Learner dashboard</SectionLabel>
          <h1 className="mt-2 font-display text-3xl font-semibold text-ink-950">
            {data.student.name}&rsquo;s profile · {data.student.subject}
          </h1>
        </div>
        <Button variant="secondary" onClick={runAnalysis} disabled={analyzing}>
          {analyzing ? "AI 1 analyzing…" : "Ask AI 1 to analyze my learning"}
        </Button>
      </div>

      {pending && (
        <Card className="mt-6 border-sky-300 bg-sky-50/70 p-6">
          <Badge tone="blue">Approval needed · AI 1 proposes a change</Badge>
          <p className="mt-3 font-display text-lg font-semibold text-ink-900">{pending.title}</p>
          <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed text-ink-800">{pending.scriptText}</p>
          <ul className="mt-3 space-y-1 text-sm text-ink-600">
            {pending.evidenceJson.map((e, i) => (
              <li key={i}>• {e}</li>
            ))}
          </ul>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Anything you want to add? (optional)"
            className="mt-4 w-full rounded-xl border border-beige-300 bg-white px-3 py-2 text-sm text-ink-900 outline-none ring-sky-400 focus:ring-2"
            rows={2}
          />
          <div className="mt-3 flex gap-3">
            <Button variant="secondary" onClick={() => resolveProposal(pending.id, "approve")} disabled={resolving}>
              Yes, make this change
            </Button>
            <Button variant="ghost" onClick={() => resolveProposal(pending.id, "reject")} disabled={resolving}>
              Not right now
            </Button>
          </div>
        </Card>
      )}

      <div className="mt-6 grid gap-5 lg:grid-cols-3">
        <Card className="p-6 lg:col-span-2">
          <SectionLabel>Topic mastery</SectionLabel>
          <div className="mt-4 space-y-4">
            {data.topics.map((t) => (
              <div key={t.id}>
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium text-ink-800">{t.title}</span>
                  <span className="text-ink-500">
                    {Math.round(t.mastery * 100)}% · {t.correct}/{t.attempts}
                  </span>
                </div>
                <div className="mt-1.5">
                  <ProgressBar value={t.mastery} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 flex gap-3">
            <Link href="/practice">
              <Button variant="ghost">Practice more →</Button>
            </Link>
          </div>
        </Card>

        <Card className="p-6">
          <SectionLabel>Session stats</SectionLabel>
          <div className="mt-4 space-y-3 text-sm text-ink-700">
            <p>
              Overall accuracy: <span className="font-semibold text-ink-900">{accuracy}%</span>
            </p>
            <p>
              Attempts logged: <span className="font-semibold text-ink-900">{data.stats.totalAttempts}</span>
            </p>
            <div className="pt-2">
              <p className="text-xs font-semibold uppercase text-emerald-600">Strengths</p>
              <p className="text-sm text-ink-600">{data.profile.strengthsJson?.join(", ") || "Still emerging"}</p>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase text-rose-600">Growth areas</p>
              <p className="text-sm text-ink-600">{data.profile.gapsJson?.join(", ") || "None flagged"}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="mt-5 p-6">
        <SectionLabel>Approved teaching strategy</SectionLabel>
        <p className="mt-2 text-sm leading-relaxed text-ink-700">{data.profile.narrative}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {Object.entries(data.profile.strategyJson ?? {}).map(([k, v]) => (
            <Badge key={k} tone="beige">
              {k}: {String(v)}
            </Badge>
          ))}
        </div>
      </Card>

      <Card className="mt-5 p-6">
        <SectionLabel>Performance by modality</SectionLabel>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {Object.entries(data.modalityMap ?? {}).map(([type, stat]) => (
            <div key={type} className="rounded-2xl border border-beige-200 p-4">
              <p className="text-sm font-semibold text-ink-800">{MODALITY_LABEL[type] ?? type}</p>
              <p className="text-xs text-ink-500">
                {stat.attempts ? Math.round((stat.correct / stat.attempts) * 100) : 0}% accuracy · avg {Math.round(stat.avgMs / 1000)}s · {stat.attempts} attempts
              </p>
            </div>
          ))}
          {Object.keys(data.modalityMap ?? {}).length === 0 && <p className="text-sm text-ink-500">No data yet — try the diagnostic or practice.</p>}
        </div>
      </Card>

      <Card className="mt-5 p-6">
        <SectionLabel>Adaptation history (the approval gate)</SectionLabel>
        {resolvedProposals.length === 0 ? (
          <p className="mt-3 text-sm text-ink-500">No resolved proposals yet.</p>
        ) : (
          <div className="mt-3 space-y-3">
            {resolvedProposals.map((p) => (
              <div key={p.id} className="rounded-2xl border border-beige-200 p-4">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-ink-800">{p.title}</p>
                  <Badge tone={p.status === "approved" ? "green" : "red"}>{p.status}</Badge>
                </div>
                <p className="mt-1 text-xs text-ink-500">{p.currentStrategy} → {p.proposedStrategy}</p>
                {p.studentNote && <p className="mt-1 text-xs italic text-ink-500">Student note: {p.studentNote}</p>}
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="mt-5 p-6">
        <SectionLabel>Retention checks (spaced repetition)</SectionLabel>
        {data.retention.length === 0 ? (
          <p className="mt-3 text-sm text-ink-500">None scheduled yet — reach 80% mastery on a topic to trigger one.</p>
        ) : (
          <div className="mt-3 space-y-3">
            {data.retention.map((r) => (
              <div key={r.id} className="rounded-2xl border border-beige-200 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-medium text-ink-800">{r.topicTitle}</p>
                    <p className="text-xs text-ink-500">
                      Due {new Date(r.dueAt).toLocaleDateString()} {r.completedAt ? "· completed" : ""}
                    </p>
                  </div>
                  {!r.completedAt && (
                    <div className="flex gap-2">
                      <Button variant="ghost" onClick={() => generateRetention(r.id)} disabled={retentionBusy === r.id}>
                        Generate question
                      </Button>
                      <Button variant="secondary" onClick={() => completeRetention(r.id)} disabled={retentionBusy === r.id}>
                        Mark reviewed
                      </Button>
                    </div>
                  )}
                </div>
                {retentionQuestion[r.id] && <p className="mt-2 text-sm text-ink-700">{retentionQuestion[r.id]}</p>}
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card className="mt-5 p-6">
        <SectionLabel>Telemetry timeline</SectionLabel>
        <div className="scrollbar-thin mt-3 max-h-64 space-y-2 overflow-y-auto pr-2 text-sm">
          {data.telemetry.map((e) => (
            <div key={e.id} className="flex items-center justify-between border-b border-beige-100 pb-2">
              <span className="font-medium text-ink-700">{e.eventType}</span>
              <span className="text-xs text-ink-400">{new Date(e.createdAt).toLocaleTimeString()}</span>
            </div>
          ))}
          {data.telemetry.length === 0 && <p className="text-ink-500">No events yet.</p>}
        </div>
      </Card>
    </main>
  );
}
