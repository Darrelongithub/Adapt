"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Button, Card, ProgressBar, SectionLabel } from "@/components/ui";
import { useStudentSession } from "@/lib/useStudent";

type Topic = { id: number; title: string; description: string };
type Question = {
  id: number;
  topicId: number;
  type: "mcq" | "numeric" | "teach_back" | "worked_example" | "visual";
  prompt: string;
  payloadJson: { choices?: string[]; steps?: string[]; diagram?: string };
  difficulty: number;
};

const TYPE_LABEL: Record<string, string> = {
  mcq: "Multiple choice",
  numeric: "Numeric answer",
  teach_back: "Teach it back",
  worked_example: "Worked example",
  visual: "Visual / diagram",
};

export default function PracticePage() {
  const router = useRouter();
  const { student, sessionId, ready } = useStudentSession();
  const [topics, setTopics] = useState<Topic[]>([]);
  const [topicId, setTopicId] = useState<number | null>(null);
  const [question, setQuestion] = useState<Question | null>(null);
  const [value, setValue] = useState("");
  const [history, setHistory] = useState<Array<{ value: string; at: number }>>([]);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [startedAt, setStartedAt] = useState(0);
  const [mastery, setMastery] = useState(0.3);
  const [loadingQ, setLoadingQ] = useState(false);
  const [feedback, setFeedback] = useState<{ correct: boolean; explanation: string; feedback?: string; scheduledRetention?: boolean } | null>(null);
  const [streak, setStreak] = useState({ answered: 0, correct: 0 });

  useEffect(() => {
    if (!ready) return;
    if (!student) {
      router.push("/onboarding");
      return;
    }
    fetch(`/api/topics?subject=${encodeURIComponent(student.subject)}`)
      .then((r) => r.json())
      .then((data) => {
        setTopics(data.topics ?? []);
        if (data.topics?.length) setTopicId(data.topics[0].id);
      });
  }, [ready, student, router]);

  useEffect(() => {
    if (!student || !topicId) return;
    loadNext(topicId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topicId, student]);

  async function loadNext(tId: number) {
    if (!student) return;
    setLoadingQ(true);
    setFeedback(null);
    setValue("");
    setHistory([]);
    setHintsUsed(0);
    setShowHint(false);
    const res = await fetch(`/api/quiz/next?studentId=${student.studentId}&topicId=${tId}`);
    const data = await res.json();
    setQuestion(data.question ?? null);
    setMastery(data.currentMastery ?? 0.3);
    setStartedAt(Date.now());
    setLoadingQ(false);
  }

  function recordChange(v: string) {
    setValue(v);
    setHistory((h) => [...h, { value: v, at: Date.now() }]);
  }

  function useHint() {
    setShowHint(true);
    setHintsUsed((n) => n + 1);
  }

  async function submitAnswer() {
    if (!student || !question) return;
    const timeSpentMs = Date.now() - startedAt;
    const res = await fetch("/api/quiz/attempt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        studentId: student.studentId,
        sessionId,
        questionId: question.id,
        kind: "practice",
        finalAnswer: value,
        answerHistory: history,
        timeSpentMs,
        hintsUsed,
      }),
    });
    const data = await res.json();
    setFeedback(data);
    setMastery(data.masteryForTopic ?? mastery);
    setStreak((s) => ({ answered: s.answered + 1, correct: s.correct + (data.correct ? 1 : 0) }));
  }

  if (!ready || !student) return null;

  return (
    <main className="mx-auto max-w-3xl px-6 py-14">
      <SectionLabel>Adaptive practice</SectionLabel>
      <h1 className="mt-2 font-display text-3xl font-semibold text-ink-950">Difficulty adjusts to your mastery in real time.</h1>

      <div className="mt-5 flex flex-wrap gap-2">
        {topics.map((t) => (
          <button
            key={t.id}
            onClick={() => setTopicId(t.id)}
            className={`rounded-full border px-4 py-2 text-sm font-medium transition ${
              topicId === t.id ? "border-ink-800 bg-ink-800 text-beige-50" : "border-beige-300 bg-beige-50 text-ink-700 hover:bg-beige-100"
            }`}
          >
            {t.title}
          </button>
        ))}
      </div>

      <Card className="mt-6 p-7">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-xs uppercase tracking-wide text-ink-500">Topic mastery</p>
          <p className="text-xs text-ink-500">
            {streak.correct}/{streak.answered} correct this session
          </p>
        </div>
        <ProgressBar value={mastery} />

        {loadingQ || !question ? (
          <p className="mt-8 text-center text-sm text-ink-500">Loading your next question…</p>
        ) : (
          <div className="mt-6 space-y-5">
            <Badge tone="blue">{TYPE_LABEL[question.type]} · difficulty {question.difficulty}</Badge>
            <h2 className="font-display text-lg font-semibold text-ink-950">{question.prompt}</h2>

            {question.type === "worked_example" && question.payloadJson.steps && (
              <ol className="list-decimal space-y-1 rounded-2xl bg-beige-100 p-4 pl-8 text-sm text-ink-700">
                {question.payloadJson.steps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ol>
            )}

            {question.type === "visual" && question.payloadJson.diagram && (
              <pre className="whitespace-pre-wrap rounded-2xl bg-ink-900 p-4 font-mono text-sm text-beige-100">
                {question.payloadJson.diagram}
              </pre>
            )}

            {!feedback && (question.type === "mcq" || question.type === "worked_example" || question.type === "visual") && question.payloadJson.choices && (
              <div className="grid gap-2">
                {question.payloadJson.choices.map((choice, i) => (
                  <button
                    key={i}
                    onClick={() => recordChange(String(i))}
                    className={`rounded-2xl border px-4 py-3 text-left text-sm font-medium transition ${
                      value === String(i) ? "border-sky-500 bg-sky-50 text-sky-700" : "border-beige-300 bg-beige-50 text-ink-700 hover:bg-beige-100"
                    }`}
                  >
                    {choice}
                  </button>
                ))}
              </div>
            )}

            {!feedback && question.type === "numeric" && (
              <input
                type="number"
                value={value}
                onChange={(e) => recordChange(e.target.value)}
                className="w-full rounded-xl border border-beige-300 bg-beige-50 px-4 py-3 text-ink-900 outline-none ring-sky-400 focus:ring-2"
              />
            )}

            {!feedback && question.type === "teach_back" && (
              <textarea
                value={value}
                onChange={(e) => recordChange(e.target.value)}
                rows={4}
                className="w-full rounded-xl border border-beige-300 bg-beige-50 px-4 py-3 text-ink-900 outline-none ring-sky-400 focus:ring-2"
              />
            )}

            {showHint && !feedback && (
              <p className="rounded-xl bg-beige-100 p-3 text-sm text-ink-600">
                Hint: think about the underlying rule step by step — you've got this.
              </p>
            )}

            {feedback && (
              <div className={`rounded-2xl border p-4 text-sm ${feedback.correct ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-rose-200 bg-rose-50 text-rose-800"}`}>
                <p className="font-semibold">{feedback.correct ? "Correct! 🎉" : "Not quite."}</p>
                <p className="mt-1">{feedback.feedback || feedback.explanation}</p>
                {feedback.scheduledRetention && (
                  <p className="mt-2 text-xs text-ink-600">
                    ✓ You&rsquo;ve reached mastery here — ADAPT scheduled a spaced retention check (see Dashboard).
                  </p>
                )}
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              {!feedback ? (
                <>
                  <Button variant="ghost" onClick={useHint} disabled={showHint}>
                    Use a hint
                  </Button>
                  <Button variant="secondary" onClick={submitAnswer} disabled={!value.trim()}>
                    Submit
                  </Button>
                </>
              ) : (
                <Button variant="primary" onClick={() => topicId && loadNext(topicId)} className="ml-auto">
                  Next question →
                </Button>
              )}
            </div>
          </div>
        )}
      </Card>
    </main>
  );
}
