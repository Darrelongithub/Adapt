"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Badge, Button, Card, SectionLabel } from "@/components/ui";
import { useStudentSession } from "@/lib/useStudent";

type Topic = { id: number; title: string };
type Message = { role: "user" | "assistant"; content: string };

export default function TutorPage() {
  const router = useRouter();
  const { student, sessionId, ready } = useStudentSession();
  const [topics, setTopics] = useState<Topic[]>([]);
  const [topicId, setTopicId] = useState<number | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [voiceMode, setVoiceMode] = useState(false);
  const [listening, setListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceName, setVoiceName] = useState<string>("");
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!ready) return;
    if (!student) {
      router.push("/onboarding");
      return;
    }
    fetch(`/api/topics?subject=${encodeURIComponent(student.subject)}`)
      .then((r) => r.json())
      .then((data) => {
        setTopics(data.topics ?? []);
        if (data.topics?.length) setTopicId(data.topics[0].id);
      });
    fetch(`/api/ai2/chat?studentId=${student.studentId}`)
      .then((r) => r.json())
      .then((data) => {
        const history = (data.history ?? []).map((m: { role: string; content: string }) => ({ role: m.role, content: m.content }));
        setMessages(
          history.length
            ? history
            : [{ role: "assistant", content: `Hi ${student.name}! I'm your ADAPT tutor. Ask me anything about ${student.subject}, by text or by voice.` }],
        );
      });
  }, [ready, student, router]);

  useEffect(() => {
    const SpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) {
      setSpeechSupported(false);
      return;
    }
    const recognition = new SpeechRecognitionCtor();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = (event) => {
      const transcript = event.results[event.results.length - 1][0].transcript;
      setInput(transcript);
      setListening(false);
      sendMessage(transcript);
    };
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognitionRef.current = recognition;

    function loadVoices() {
      const list = window.speechSynthesis.getVoices();
      setVoices(list);
      if (!voiceName && list.length) setVoiceName(list.find((v) => v.lang.startsWith("en"))?.name ?? list[0].name);
    }
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  function startListening() {
    if (!recognitionRef.current) return;
    window.speechSynthesis.cancel(); // barge-in: stop tutor from talking
    setListening(true);
    recognitionRef.current.start();
  }

  function stopListening() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  function speak(text: string) {
    if (!voiceMode || typeof window === "undefined" || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const chosen = voices.find((v) => v.name === voiceName);
    if (chosen) utterance.voice = chosen;
    utterance.rate = 1;
    window.speechSynthesis.speak(utterance);
  }

  async function sendMessage(forcedText?: string) {
    const text = (forcedText ?? input).trim();
    if (!text || !student) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: text }]);
    setSending(true);
    try {
      const res = await fetch("/api/ai2/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId: student.studentId, sessionId, topicId, message: text, voiceMode }),
      });
      const data = await res.json();
      const reply = data.reply ?? "Sorry, I couldn't respond just now.";
      setMessages((m) => [...m, { role: "assistant", content: reply }]);
      speak(reply);
    } finally {
      setSending(false);
    }
  }

  if (!ready || !student) return null;

  return (
    <main className="mx-auto max-w-3xl px-6 py-14">
      <SectionLabel>Real-time tutor · AI 2</SectionLabel>
      <h1 className="mt-2 font-display text-3xl font-semibold text-ink-950">Talk it through — by text or by voice.</h1>
      <p className="mt-2 text-sm text-ink-600">
        Uses your browser&rsquo;s built-in speech engine (free, local, zero API cost) for recognition and
        natural voice playback, with barge-in: start talking and the tutor stops to listen.
      </p>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <select
          value={topicId ?? ""}
          onChange={(e) => setTopicId(Number(e.target.value))}
          className="rounded-full border border-beige-300 bg-beige-50 px-4 py-2 text-sm font-medium text-ink-700"
        >
          {topics.map((t) => (
            <option key={t.id} value={t.id}>
              {t.title}
            </option>
          ))}
        </select>

        <button
          onClick={() => setVoiceMode((v) => !v)}
          className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
            voiceMode ? "border-sky-500 bg-sky-50 text-sky-700" : "border-beige-300 bg-beige-50 text-ink-700"
          }`}
        >
          {voiceMode ? "🔊 Voice: On" : "🔇 Voice: Off"}
        </button>

        {voices.length > 0 && (
          <select
            value={voiceName}
            onChange={(e) => setVoiceName(e.target.value)}
            className="rounded-full border border-beige-300 bg-beige-50 px-3 py-2 text-xs text-ink-700"
          >
            {voices
              .filter((v) => v.lang.startsWith("en"))
              .map((v) => (
                <option key={v.name} value={v.name}>
                  {v.name}
                </option>
              ))}
          </select>
        )}
      </div>

      <Card className="mt-6 flex h-[460px] flex-col p-5">
        <div ref={scrollRef} className="scrollbar-thin flex-1 space-y-3 overflow-y-auto pr-2">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                  m.role === "user" ? "bg-ink-800 text-beige-50" : "bg-beige-100 text-ink-800"
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}
          {sending && <div className="text-xs text-ink-400">AI 2 is thinking…</div>}
        </div>

        <div className="mt-4 flex items-center gap-2">
          {speechSupported && (
            <button
              onClick={listening ? stopListening : startListening}
              className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-lg text-white ${
                listening ? "voice-pulse bg-rose-500" : "bg-sky-600 hover:bg-sky-700"
              }`}
              title={listening ? "Stop listening" : "Start speaking"}
            >
              🎙️
            </button>
          )}
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder={speechSupported ? "Type, or tap the mic to talk…" : "Type your question…"}
            className="flex-1 rounded-full border border-beige-300 bg-beige-50 px-4 py-2.5 text-sm text-ink-900 outline-none ring-sky-400 focus:ring-2"
          />
          <Button variant="secondary" onClick={() => sendMessage()} disabled={sending || !input.trim()}>
            Send
          </Button>
        </div>
        {!speechSupported && <p className="mt-2 text-xs text-ink-400">Speech recognition isn&rsquo;t supported in this browser — try Chrome or Edge.</p>}
      </Card>

      <div className="mt-4">
        <Badge tone="beige">AI 2 reads your live mastery + approved strategy before every reply</Badge>
      </div>
    </main>
  );
}
