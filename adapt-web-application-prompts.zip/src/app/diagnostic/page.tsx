"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Badge, Button, Card, ProgressBar, SectionLabel } from "@/components/ui";
import { useStudentSession } from "@/lib/useStudent";

type Question = {
  id: number;
  topicId: number;
  kind: string;
  type: "mcq" | "numeric" | "teach_back" | "worked_example" | "visual";
  prompt: string;
  payloadJson: Record<string, unknown>;
  difficulty: number;
};

type AnswerEvent = { value: string; at: number };

const TYPE_LABEL: Record<string, string> = {
  mcq: "Multiple choice",
  numeric: "Numeric answer",
  teach_back: "Teach it back",
  worked_example: "Worked example",
  visual: "Visual / diagram",
};

export default function DiagnosticPage() {
  const router = useRouter();
  const { student, sessionId, ready } = useStudentSession();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [index, setIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [currentValue, setCurrentValue] = useState("");
  const [history, setHistory] = useState<AnswerEvent[]>([]);
  const [startedAt, setStartedAt] = useState(0);
  const [responses, setResponses] = useState<
    Array<{ questionId: number; finalAnswer: string; answerHistory: AnswerEvent[]; timeSpentMs: number; hintsUsed: number }>
  >([]);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ strengths: string[]; gaps: string[]; narrative: string } | null>(null);

  useEffect(() => {
    if (!ready) return;
    if (!student) {
      router.push("/onboarding");
      return;
    }
    fetch(`/api/diagnostic/questions?subject=${encodeURIComponent(student.subject)}`)
      .then((r) => r.json())
      .then((data) => {
        setQuestions(data.questions ?? []);
        setStartedAt(Date.now());
        setLoading(false);
      });
  }, [ready, student, router]);

  const current = questions[index];
  const progress = questions.length ? index / questions.length : 0;

  function recordChange(value: string) {
    setCurrentValue(value);
    setHistory((h) => [...h, { value, at: Date.now() }]);
  }

  async function handleNext() {
    if (!current) return;
    const timeSpentMs = Date.now() - startedAt;
    const next = [...responses, { questionId: current.id, finalAnswer: currentValue, answerHistory: history, timeSpentMs, hintsUsed: 0 }];
    setResponses(next);
    setCurrentValue("");
    setHistory([]);
    setStartedAt(Date.now());

    if (index + 1 < questions.length) {
      setIndex(index + 1);
      return;
    }

    if (!student) return;
    setSubmitting(true);
    const res = await fetch("/api/diagnostic/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ studentId: student.studentId, sessionId, responses: next }),
    });
    const data = await res.json();
    setResult(data);
    setSubmitting(false);
  }

  const canContinue = useMemo(() => currentValue.trim().length > 0, [currentValue]);

  if (!ready || loading) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-24 text-center text-ink-500">
        Preparing your diagnostic…
      </main>
    );
  }

  if (result) {
    return (
      <main className="mx-auto max-w-2xl px-6 py-16">
        <SectionLabel>Diagnostic complete</SectionLabel>
        <h1 className="mt-2 font-display text-3xl font-semibold text-ink-950">Here&rsquo;s your first learner profile.</h1>
        <Card className="mt-6 space-y-5 p-7">
          <p className="text-sm leading-relaxed text-ink-700">{result.narrative}</p>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-emerald-600">Strengths</p>
              <ul className="mt-2 space-y-1 text-sm text-ink-700">
                {result.strengths.length ? result.strengths.map((s) => <li key={s}>• {s}</li>) : <li>Still gathering evidence</li>}
              </ul>
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-rose-600">Growth areas</p>
              <ul className="mt-2 space-y-1 text-sm text-ink-700">
                {result.gaps.length ? result.gaps.map((s) => <li key={s}>• {s}</li>) : <li>None flagged yet</li>}
              </ul>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 pt-2">
            <Link href="/dashboard">
              <Button variant="primary">See full dashboard →</Button>
            </Link>
            <Link href="/practice">
              <Button variant="secondary">Start adaptive practice</Button>
            </Link>
            <Link href="/tutor">
              <Button variant="ghost">Talk to the voice tutor</Button>
            </Link>
          </div>
        </Card>
      </main>
    );
  }

  if (!current) {
    return <main className="mx-auto max-w-2xl px-6 py-24 text-center text-ink-500">No diagnostic questions found.</main>;
  }

  const payload = current.payloadJson as {
    choices?: string[];
    steps?: string[];
    diagram?: string;
  };

  return (
    <main className="mx-auto max-w-2xl px-6 py-14">
      <SectionLabel>Step 2 of 4 — Diagnostic assessment</SectionLabel>
      <div className="mt-3">
        <ProgressBar value={progress} />
        <p className="mt-2 text-xs text-ink-500">
          Question {index + 1} of {questions.length}
        </p>
      </div>

      <Card className="mt-6 space-y-5 p-7">
        <Badge tone="blue">{TYPE_LABEL[current.type]}</Badge>
        <h2 className="font-display text-xl font-semibold text-ink-950">{current.prompt}</h2>

        {current.type === "worked_example" && payload.steps && (
          <ol className="list-decimal space-y-1 rounded-2xl bg-beige-100 p-4 pl-8 text-sm text-ink-700">
            {payload.steps.map((s, i) => (
              <li key={i}>{s}</li>
            ))}
          </ol>
        )}

        {current.type === "visual" && payload.diagram && (
          <pre className="whitespace-pre-wrap rounded-2xl bg-ink-900 p-4 font-mono text-sm text-beige-100">{payload.diagram}</pre>
        )}

        {(current.type === "mcq" || current.type === "worked_example" || current.type === "visual") && payload.choices && (
          <div className="grid gap-2">
            {payload.choices.map((choice, i) => (
              <button
                key={i}
                onClick={() => recordChange(String(i))}
                className={`rounded-2xl border px-4 py-3 text-left text-sm font-medium transition ${
                  currentValue === String(i)
                    ? "border-sky-500 bg-sky-50 text-sky-700"
                    : "border-beige-300 bg-beige-50 text-ink-700 hover:bg-beige-100"
                }`}
              >
                {choice}
              </button>
            ))}
          </div>
        )}

        {current.type === "numeric" && (
          <input
            type="number"
            value={currentValue}
            onChange={(e) => recordChange(e.target.value)}
            placeholder="Type your answer"
            className="w-full rounded-xl border border-beige-300 bg-beige-50 px-4 py-3 text-ink-900 outline-none ring-sky-400 focus:ring-2"
          />
        )}

        {current.type === "teach_back" && (
          <textarea
            value={currentValue}
            onChange={(e) => recordChange(e.target.value)}
            rows={4}
            placeholder="Explain it in your own words…"
            className="w-full rounded-xl border border-beige-300 bg-beige-50 px-4 py-3 text-ink-900 outline-none ring-sky-400 focus:ring-2"
          />
        )}

        <div className="flex items-center justify-between pt-2">
          <p className="text-xs text-ink-400">{history.length > 0 ? `${history.length} change(s) tracked` : "We're timing this question"}</p>
          <Button variant="secondary" onClick={handleNext} disabled={!canContinue || submitting}>
            {submitting ? "Building your profile…" : index + 1 === questions.length ? "Finish diagnostic" : "Next →"}
          </Button>
        </div>
      </Card>
    </main>
  );
}
