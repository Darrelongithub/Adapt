"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button, Card, SectionLabel } from "@/components/ui";
import { useStudentSession } from "@/lib/useStudent";

const SUBJECTS = ["Algebra Foundations", "Cell Biology"];
const GRADES = ["Middle School", "High School", "Early College", "Adult learner"];

export default function OnboardingPage() {
  const router = useRouter();
  const { setStudent } = useStudentSession();
  const [name, setName] = useState("");
  const [gradeLevel, setGradeLevel] = useState(GRADES[1]);
  const [subject, setSubject] = useState(SUBJECTS[0]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit() {
    if (!name.trim()) {
      setError("Tell us your name so ADAPT can greet you properly.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, gradeLevel, subject }),
      });
      if (!res.ok) throw new Error("Could not create your learner profile.");
      const data = await res.json();
      setStudent({ studentId: data.student.id, name: data.student.name, subject: data.student.subject });
      router.push("/diagnostic");
    } catch {
      setError("Something went wrong — please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <SectionLabel>Step 1 of 4 — Onboarding</SectionLabel>
      <h1 className="mt-2 font-display text-3xl font-semibold text-ink-950">Let&rsquo;s set up your learner profile.</h1>
      <p className="mt-2 text-sm text-ink-600">
        This takes 30 seconds. Next you&rsquo;ll take a short diagnostic so ADAPT has real evidence to
        work with — not guesses.
      </p>

      <Card className="mt-8 space-y-6 p-7">
        <div>
          <label className="text-sm font-semibold text-ink-800">Your name</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Jordan"
            className="mt-2 w-full rounded-xl border border-beige-300 bg-beige-50 px-4 py-3 text-ink-900 outline-none ring-sky-400 focus:ring-2"
          />
        </div>

        <div>
          <label className="text-sm font-semibold text-ink-800">Grade / level</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {GRADES.map((g) => (
              <button
                key={g}
                onClick={() => setGradeLevel(g)}
                className={`rounded-full border px-4 py-2 text-sm font-medium transition ${
                  gradeLevel === g ? "border-ink-800 bg-ink-800 text-beige-50" : "border-beige-300 bg-beige-50 text-ink-700 hover:bg-beige-100"
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-semibold text-ink-800">Subject to focus on</label>
          <div className="mt-2 grid gap-2 sm:grid-cols-2">
            {SUBJECTS.map((s) => (
              <button
                key={s}
                onClick={() => setSubject(s)}
                className={`rounded-2xl border px-4 py-4 text-left text-sm font-medium transition ${
                  subject === s ? "border-sky-500 bg-sky-50 text-sky-700" : "border-beige-300 bg-beige-50 text-ink-700 hover:bg-beige-100"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-sm text-rose-600">{error}</p>}

        <Button variant="secondary" onClick={handleSubmit} disabled={loading} className="w-full">
          {loading ? "Setting up…" : "Continue to diagnostic →"}
        </Button>
      </Card>
    </main>
  );
}
