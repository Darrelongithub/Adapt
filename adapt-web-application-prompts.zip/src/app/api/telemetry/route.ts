import { db } from "@/db";
import { telemetryEvents } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { recordTelemetry } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const studentId = Number(body.studentId);
  const sessionId = String(body.sessionId ?? "session");
  const eventType = String(body.eventType ?? "event");
  const payload = typeof body.payload === "object" && body.payload ? body.payload : {};
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });
  await recordTelemetry(studentId, sessionId, eventType, payload);
  return Response.json({ ok: true });
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });
  const limit = Math.min(200, Number(searchParams.get("limit") ?? 50));
  const events = await db
    .select()
    .from(telemetryEvents)
    .where(eq(telemetryEvents.studentId, studentId))
    .orderBy(desc(telemetryEvents.createdAt))
    .limit(limit);
  return Response.json({ events });
}
