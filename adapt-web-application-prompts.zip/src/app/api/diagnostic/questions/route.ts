import { db } from "@/db";
import { questions, topics } from "@/db/schema";
import { eq, inArray, asc } from "drizzle-orm";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(req.url);
  const subject = searchParams.get("subject");
  if (!subject) return Response.json({ error: "subject required" }, { status: 400 });

  const subjectTopics = await db.select().from(topics).where(eq(topics.subject, subject)).orderBy(asc(topics.orderIndex));
  const topicIds = subjectTopics.map((t) => t.id);
  if (topicIds.length === 0) return Response.json({ topics: [], questions: [] });

  const diagnosticQuestions = await db
    .select()
    .from(questions)
    .where(inArray(questions.topicId, topicIds))
    .then((rows) => rows.filter((r) => r.kind === "diagnostic"));

  // Strip answer keys before sending to the client.
  const sanitized = diagnosticQuestions.map((q) => {
    const payload = q.payloadJson as Record<string, unknown>;
    const { correctIndex: _ci, correctValue: _cv, explanation: _ex, ...rest } = payload;
    void _ci;
    void _cv;
    void _ex;
    return { ...q, payloadJson: rest };
  });

  return Response.json({ topics: subjectTopics, questions: sanitized });
}
