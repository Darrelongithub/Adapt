import { db } from "@/db";
import { questions, quizAttempts, students } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";
import { gradeAnswer } from "@/lib/grading";
import { asMasteryMap, asModalityMap, getOrCreateProfile, getTopicLabelMap, recordTelemetry } from "@/lib/profile";
import { masterySummaryText, modalitySummaryText, updateModalityStat, updateTopicMastery } from "@/lib/mastery";
import { generateText, geminiEnabled } from "@/lib/gemini";
import { AI1_LEARNING_INTELLIGENCE_SYSTEM_PROMPT } from "@/lib/prompts";
import { learnerProfiles } from "@/db/schema";

export const dynamic = "force-dynamic";

type ResponseInput = {
  questionId: number;
  finalAnswer: string;
  answerHistory: Array<{ value: string; at: number }>;
  timeSpentMs: number;
  hintsUsed: number;
};

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const studentId = Number(body.studentId);
  const sessionId = String(body.sessionId ?? "diagnostic");
  const responses: ResponseInput[] = Array.isArray(body.responses) ? body.responses : [];
  if (!studentId || responses.length === 0) {
    return Response.json({ error: "studentId and responses required" }, { status: 400 });
  }

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  const qIds = responses.map((r) => r.questionId);
  const questionRows = await db.select().from(questions).where(inArray(questions.id, qIds));
  const questionMap = new Map(questionRows.map((q) => [q.id, q]));

  const profile = await getOrCreateProfile(studentId);
  let masteryMap = asMasteryMap(profile.masteryJson);
  let modalityMap = asModalityMap(profile.modalityJson);

  const results: Array<{ questionId: number; correct: boolean; score: number; explanation: string; feedback?: string }> = [];

  for (const r of responses) {
    const q = questionMap.get(r.questionId);
    if (!q) continue;
    const grade = await gradeAnswer(
      { id: q.id, type: q.type, prompt: q.prompt, payloadJson: q.payloadJson as Record<string, unknown> },
      r.finalAnswer,
    );
    results.push({ questionId: q.id, correct: grade.correct, score: grade.score, explanation: grade.explanation, feedback: grade.feedback });

    masteryMap = updateTopicMastery(masteryMap, String(q.topicId), grade.correct);
    modalityMap = updateModalityStat(modalityMap, q.type, grade.correct, r.timeSpentMs ?? 0);

    await db.insert(quizAttempts).values({
      studentId,
      questionId: q.id,
      kind: "diagnostic",
      answerHistoryJson: r.answerHistory ?? [],
      finalAnswer: r.finalAnswer,
      correct: grade.correct,
      score: grade.score,
      timeSpentMs: r.timeSpentMs ?? 0,
      hintsUsed: r.hintsUsed ?? 0,
    });

    await recordTelemetry(studentId, sessionId, "diagnostic_answered", {
      questionId: q.id,
      type: q.type,
      changes: (r.answerHistory ?? []).length,
      correct: grade.correct,
      timeSpentMs: r.timeSpentMs ?? 0,
    });
  }

  const topicLabels = await getTopicLabelMap(student.subject);
  const strengths = Object.entries(masteryMap)
    .filter(([, v]) => v.mastery >= 0.6)
    .map(([k]) => topicLabels[k] ?? k);
  const gaps = Object.entries(masteryMap)
    .filter(([, v]) => v.mastery < 0.45)
    .map(([k]) => topicLabels[k] ?? k);

  let narrative = "";
  const masterySummary = masterySummaryText(masteryMap, topicLabels);
  const modalitySummary = modalitySummaryText(modalityMap);
  if (geminiEnabled()) {
    try {
      narrative = await generateText({
        system: AI1_LEARNING_INTELLIGENCE_SYSTEM_PROMPT,
        prompt: `Write a short (3-4 sentence) internal note (for the learner profile, not shown with jargon) summarizing this learner's diagnostic results in subject ${student.subject}.\n\nMastery:\n${masterySummary}\n\nModality performance:\n${modalitySummary}\n\nStrengths: ${strengths.join(", ") || "none yet"}\nGaps: ${gaps.join(", ") || "none yet"}`,
      });
    } catch {
      narrative = "";
    }
  }
  if (!narrative) {
    narrative = `Diagnostic complete for ${student.subject}. Strengths: ${strengths.join(", ") || "still emerging"}. Growth areas: ${gaps.join(", ") || "none flagged yet"}. ADAPT will keep refining this profile as more evidence comes in.`;
  }

  await db
    .update(learnerProfiles)
    .set({
      masteryJson: masteryMap,
      modalityJson: modalityMap,
      strengthsJson: strengths,
      gapsJson: gaps,
      narrative,
      updatedAt: new Date(),
    })
    .where(eq(learnerProfiles.studentId, studentId));

  await recordTelemetry(studentId, sessionId, "diagnostic_completed", { strengths, gaps });

  return Response.json({ results, strengths, gaps, narrative });
}
