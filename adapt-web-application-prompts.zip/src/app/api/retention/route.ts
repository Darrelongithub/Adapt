import { db } from "@/db";
import { retentionChecks, topics } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { generateJson, geminiEnabled } from "@/lib/gemini";
import { RETENTION_CHECK_SYSTEM_PROMPT } from "@/lib/prompts";
import { recordTelemetry } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });

  const rows = await db
    .select({
      id: retentionChecks.id,
      topicId: retentionChecks.topicId,
      dueAt: retentionChecks.dueAt,
      completedAt: retentionChecks.completedAt,
      resultJson: retentionChecks.resultJson,
      createdAt: retentionChecks.createdAt,
      topicTitle: topics.title,
    })
    .from(retentionChecks)
    .leftJoin(topics, eq(retentionChecks.topicId, topics.id))
    .where(eq(retentionChecks.studentId, studentId))
    .orderBy(desc(retentionChecks.createdAt));

  return Response.json({ checks: rows });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const checkId = Number(body.checkId);
  const action = body.action; // "generate" | "complete"
  if (!checkId) return Response.json({ error: "checkId required" }, { status: 400 });

  const [check] = await db.select().from(retentionChecks).where(eq(retentionChecks.id, checkId)).limit(1);
  if (!check) return Response.json({ error: "not found" }, { status: 404 });

  if (action === "generate") {
    const [topic] = await db.select().from(topics).where(eq(topics.id, check.topicId)).limit(1);
    const daysSince = Math.max(0, Math.round((Date.now() - check.createdAt.getTime()) / (1000 * 60 * 60 * 24)));
    let generated = { question: "", expectedAnswerNotes: "", rationale: "" };
    if (geminiEnabled()) {
      try {
        generated = await generateJson({
          system: RETENTION_CHECK_SYSTEM_PROMPT,
          prompt: `Topic: ${topic?.title ?? "topic"}. Days since mastery reached: ${daysSince}.`,
        });
      } catch {
        generated = {
          question: `Quick recall: explain the core idea of "${topic?.title}" in one or two sentences.`,
          expectedAnswerNotes: "Any reasonable restatement of the core concept counts.",
          rationale: `Spacing this check out helps fight the forgetting curve (${daysSince} days since last practice).`,
        };
      }
    } else {
      generated = {
        question: `Quick recall: explain the core idea of "${topic?.title}" in one or two sentences.`,
        expectedAnswerNotes: "Any reasonable restatement of the core concept counts.",
        rationale: `Spacing this check out helps fight the forgetting curve (${daysSince} days since last practice).`,
      };
    }
    const resultJson = { ...((check.resultJson as Record<string, unknown>) ?? {}), generated };
    await db.update(retentionChecks).set({ resultJson }).where(eq(retentionChecks.id, checkId));
    return Response.json({ generated });
  }

  if (action === "complete") {
    const answer = String(body.answer ?? "");
    const resultJson = { ...((check.resultJson as Record<string, unknown>) ?? {}), studentAnswer: answer };
    await db.update(retentionChecks).set({ completedAt: new Date(), resultJson }).where(eq(retentionChecks.id, checkId));
    await recordTelemetry(check.studentId, "retention", "retention_completed", { checkId, topicId: check.topicId });
    return Response.json({ ok: true });
  }

  return Response.json({ error: "invalid action" }, { status: 400 });
}
