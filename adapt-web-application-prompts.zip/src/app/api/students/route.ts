import { db } from "@/db";
import { students } from "@/db/schema";
import { ensureSeeded, SUBJECT_NAMES } from "@/lib/seed";
import { getOrCreateProfile } from "@/lib/profile";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureSeeded();
  const body = await req.json().catch(() => ({}));
  const name = typeof body.name === "string" && body.name.trim() ? body.name.trim() : "Learner";
  const gradeLevel = typeof body.gradeLevel === "string" ? body.gradeLevel : "";
  const subject = SUBJECT_NAMES.includes(body.subject) ? body.subject : SUBJECT_NAMES[0];

  const [student] = await db.insert(students).values({ name, gradeLevel, subject }).returning();
  await getOrCreateProfile(student.id);

  return Response.json({ student, subjects: SUBJECT_NAMES });
}

export async function GET(req: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (id) {
    const [student] = await db.select().from(students).where(eq(students.id, Number(id))).limit(1);
    if (!student) return Response.json({ error: "not found" }, { status: 404 });
    return Response.json({ student });
  }
  return Response.json({ subjects: SUBJECT_NAMES });
}
