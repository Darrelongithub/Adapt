import { db } from "@/db";
import { resourceCache, topics, learnerProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { searchAllResources } from "@/lib/resources";
import { generateJson, geminiEnabled } from "@/lib/gemini";
import { RESOURCE_CURATION_SYSTEM_PROMPT } from "@/lib/prompts";
import { asMasteryMap } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const topicId = Number(searchParams.get("topicId"));
  const studentId = Number(searchParams.get("studentId") || 0);
  if (!topicId) return Response.json({ error: "topicId required" }, { status: 400 });

  const [topic] = await db.select().from(topics).where(eq(topics.id, topicId)).limit(1);
  if (!topic) return Response.json({ error: "topic not found" }, { status: 404 });

  let cached = await db.select().from(resourceCache).where(eq(resourceCache.topicId, topicId));
  if (cached.length === 0) {
    const found = await searchAllResources(`${topic.title} ${topic.subject}`);
    if (found.length) {
      await db.insert(resourceCache).values(
        found.map((f) => ({ topicId, source: f.source, title: f.title, url: f.url, metadataJson: f.metadata })),
      );
      cached = await db.select().from(resourceCache).where(eq(resourceCache.topicId, topicId));
    }
  }

  if (cached.length === 0) return Response.json({ picks: [], raw: [] });

  let mastery = 0.3;
  if (studentId) {
    const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.studentId, studentId)).limit(1);
    if (profile) mastery = asMasteryMap(profile.masteryJson)[String(topicId)]?.mastery ?? 0.3;
  }

  if (geminiEnabled()) {
    try {
      const curated = await generateJson<{ picks: Array<{ title: string; url: string; source: string; why: string }> }>({
        system: RESOURCE_CURATION_SYSTEM_PROMPT,
        prompt: `Topic: ${topic.title} (${topic.subject}). Learner mastery: ${Math.round(mastery * 100)}%.\nRaw results:\n${cached
          .map((c) => `- [${c.source}] ${c.title} :: ${c.url}`)
          .join("\n")}`,
      });
      return Response.json({ picks: curated.picks, raw: cached });
    } catch {
      // fall through
    }
  }

  const picks = cached.slice(0, 4).map((c) => ({
    title: c.title,
    url: c.url,
    source: c.source,
    why: mastery < 0.5 ? "A gentle, accessible intro to build foundations." : "A deeper resource to push past the basics.",
  }));
  return Response.json({ picks, raw: cached });
}
