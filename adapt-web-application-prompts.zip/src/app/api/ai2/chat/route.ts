import { db } from "@/db";
import { chatMessages, students, topics } from "@/db/schema";
import { eq, desc, asc } from "drizzle-orm";
import { asMasteryMap, getOrCreateProfile, getTopicLabelMap, recordTelemetry } from "@/lib/profile";
import { masterySummaryText } from "@/lib/mastery";
import { generateText, geminiEnabled } from "@/lib/gemini";
import { AI2_EDUCATIONAL_INTELLIGENCE_SYSTEM_PROMPT, buildAi2ChatPrompt } from "@/lib/prompts";
import { searchAllResources } from "@/lib/resources";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const studentId = Number(body.studentId);
  const sessionId = String(body.sessionId ?? "tutor");
  const topicId = body.topicId ? Number(body.topicId) : null;
  const message = String(body.message ?? "").trim();
  const voiceMode = Boolean(body.voiceMode);
  if (!studentId || !message) return Response.json({ error: "studentId and message required" }, { status: 400 });

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  const profile = await getOrCreateProfile(studentId);
  const topicLabels = await getTopicLabelMap(student.subject);
  const masteryMap = asMasteryMap(profile.masteryJson);

  let topicTitle = "general";
  let resourceSnippets = "None fetched for this message.";
  if (topicId) {
    const [topic] = await db.select().from(topics).where(eq(topics.id, topicId)).limit(1);
    if (topic) {
      topicTitle = topic.title;
      try {
        const found = await searchAllResources(`${topic.title} ${topic.subject}`);
        resourceSnippets = found
          .slice(0, 4)
          .map((f) => `- [${f.source}] ${f.title} :: ${f.url}`)
          .join("\n") || "None found.";
      } catch {
        resourceSnippets = "None found.";
      }
    }
  }

  const history = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.studentId, studentId))
    .orderBy(desc(chatMessages.createdAt))
    .limit(8);
  const historyText =
    history
      .slice()
      .reverse()
      .map((m) => `${m.role === "user" ? "Student" : "Tutor"}: ${m.content}`)
      .join("\n") || "No prior conversation.";

  await db.insert(chatMessages).values({
    studentId,
    sessionId,
    role: "user",
    aiSystem: "ai2",
    content: message,
    modality: voiceMode ? "voice" : "text",
  });

  let reply = "";
  if (geminiEnabled()) {
    try {
      reply = await generateText({
        system: AI2_EDUCATIONAL_INTELLIGENCE_SYSTEM_PROMPT,
        prompt: buildAi2ChatPrompt({
          studentName: student.name,
          subject: student.subject,
          topicTitle,
          masterySummary: masterySummaryText(masteryMap, topicLabels),
          strategy: JSON.stringify(profile.strategyJson),
          history: historyText,
          userMessage: message,
          resourceSnippets,
          voiceMode,
        }),
        temperature: 0.7,
      });
    } catch {
      reply = "";
    }
  }

  if (!reply) {
    reply = `Good question about ${topicTitle}! While my full AI brain (Gemini) isn't connected in this environment, here's the idea: break it into smaller steps, try a worked example first, then test yourself without looking. Want me to give you a quick practice question on ${topicTitle}?`;
  }

  await db.insert(chatMessages).values({
    studentId,
    sessionId,
    role: "assistant",
    aiSystem: "ai2",
    content: reply,
    modality: voiceMode ? "voice" : "text",
  });

  await recordTelemetry(studentId, sessionId, "tutor_message", { voiceMode, topicId, length: message.length });

  return Response.json({ reply });
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });
  const history = await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.studentId, studentId))
    .orderBy(asc(chatMessages.createdAt))
    .limit(100);
  return Response.json({ history });
}
