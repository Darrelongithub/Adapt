import { db } from "@/db";
import { questions, quizAttempts, learnerProfiles, retentionChecks } from "@/db/schema";
import { eq } from "drizzle-orm";
import { gradeAnswer } from "@/lib/grading";
import { asMasteryMap, asModalityMap, getOrCreateProfile, recordTelemetry } from "@/lib/profile";
import { updateModalityStat, updateTopicMastery } from "@/lib/mastery";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const studentId = Number(body.studentId);
  const sessionId = String(body.sessionId ?? "practice");
  const questionId = Number(body.questionId);
  const kind = typeof body.kind === "string" ? body.kind : "practice";
  const finalAnswer = String(body.finalAnswer ?? "");
  const answerHistory = Array.isArray(body.answerHistory) ? body.answerHistory : [];
  const timeSpentMs = Number(body.timeSpentMs ?? 0);
  const hintsUsed = Number(body.hintsUsed ?? 0);

  if (!studentId || !questionId) return Response.json({ error: "studentId and questionId required" }, { status: 400 });

  const [q] = await db.select().from(questions).where(eq(questions.id, questionId)).limit(1);
  if (!q) return Response.json({ error: "question not found" }, { status: 404 });

  const grade = await gradeAnswer({ id: q.id, type: q.type, prompt: q.prompt, payloadJson: q.payloadJson as Record<string, unknown> }, finalAnswer);

  const profile = await getOrCreateProfile(studentId);
  const masteryMap = updateTopicMastery(asMasteryMap(profile.masteryJson), String(q.topicId), grade.correct);
  const modalityMap = updateModalityStat(asModalityMap(profile.modalityJson), q.type, grade.correct, timeSpentMs);

  const strengths = Object.entries(masteryMap)
    .filter(([, v]) => v.mastery >= 0.6)
    .map(([k]) => k);
  const gaps = Object.entries(masteryMap)
    .filter(([, v]) => v.mastery < 0.45)
    .map(([k]) => k);

  await db
    .update(learnerProfiles)
    .set({ masteryJson: masteryMap, modalityJson: modalityMap, strengthsJson: strengths, gapsJson: gaps, updatedAt: new Date() })
    .where(eq(learnerProfiles.studentId, studentId));

  await db.insert(quizAttempts).values({
    studentId,
    questionId,
    kind,
    answerHistoryJson: answerHistory,
    finalAnswer,
    correct: grade.correct,
    score: grade.score,
    timeSpentMs,
    hintsUsed,
  });

  await recordTelemetry(studentId, sessionId, "practice_answered", {
    questionId,
    topicId: q.topicId,
    type: q.type,
    correct: grade.correct,
    changes: answerHistory.length,
    timeSpentMs,
    hintsUsed,
  });

  // Schedule a retention check once mastery crosses the "learned it" threshold.
  const topicMastery = masteryMap[String(q.topicId)]?.mastery ?? 0;
  let scheduledRetention = false;
  if (topicMastery >= 0.8) {
    const existing = await db
      .select({ id: retentionChecks.id })
      .from(retentionChecks)
      .where(eq(retentionChecks.topicId, q.topicId))
      .limit(1);
    if (existing.length === 0) {
      const dueAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 3); // +3 days (Ebbinghaus-informed spacing)
      await db.insert(retentionChecks).values({ studentId, topicId: q.topicId, dueAt, resultJson: {} });
      scheduledRetention = true;
    }
  }

  return Response.json({
    correct: grade.correct,
    score: grade.score,
    explanation: grade.explanation,
    feedback: grade.feedback,
    masteryForTopic: topicMastery,
    scheduledRetention,
  });
}
