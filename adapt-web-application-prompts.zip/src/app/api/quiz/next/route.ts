import { db } from "@/db";
import { questions, quizAttempts, students } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { getOrCreateProfile } from "@/lib/profile";
import { asMasteryMap } from "@/lib/profile";
import { pickNextDifficulty } from "@/lib/mastery";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  const topicId = Number(searchParams.get("topicId"));
  if (!studentId || !topicId) return Response.json({ error: "studentId and topicId required" }, { status: 400 });

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  const profile = await getOrCreateProfile(studentId);
  const masteryMap = asMasteryMap(profile.masteryJson);
  const topicMastery = masteryMap[String(topicId)]?.mastery ?? 0.3;
  const targetDifficulty = pickNextDifficulty(topicMastery);

  const pool = await db
    .select()
    .from(questions)
    .where(and(eq(questions.topicId, topicId), eq(questions.kind, "practice")));

  if (pool.length === 0) return Response.json({ question: null });

  // Recently attempted question ids for this student in this topic (avoid repeats).
  const recent = await db
    .select({ questionId: quizAttempts.questionId })
    .from(quizAttempts)
    .where(eq(quizAttempts.studentId, studentId))
    .orderBy(desc(quizAttempts.createdAt))
    .limit(5);
  const recentIds = new Set(recent.map((r) => r.questionId));

  const byDifficulty = pool.filter((q) => q.difficulty === targetDifficulty && !recentIds.has(q.id));
  const fallbackPool = pool.filter((q) => !recentIds.has(q.id));
  const finalPool = byDifficulty.length ? byDifficulty : fallbackPool.length ? fallbackPool : pool;

  const chosen = finalPool[Math.floor(Math.random() * finalPool.length)];
  const payload = chosen.payloadJson as Record<string, unknown>;
  const { correctIndex: _ci, correctValue: _cv, explanation: _ex, ...rest } = payload;
  void _ci;
  void _cv;
  void _ex;

  return Response.json({ question: { ...chosen, payloadJson: rest }, targetDifficulty, currentMastery: topicMastery });
}
