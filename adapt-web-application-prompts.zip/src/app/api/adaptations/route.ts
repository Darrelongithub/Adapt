import { db } from "@/db";
import { adaptationProposals } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });

  const rows = await db
    .select()
    .from(adaptationProposals)
    .where(eq(adaptationProposals.studentId, studentId))
    .orderBy(desc(adaptationProposals.createdAt));

  return Response.json({ proposals: rows });
}
