import { db } from "@/db";
import { adaptationProposals, learnerProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { recordTelemetry } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const proposalId = Number(id);
  const body = await req.json().catch(() => ({}));
  const action = body.action === "approve" ? "approved" : body.action === "reject" ? "rejected" : null;
  const note = typeof body.note === "string" ? body.note : "";
  const sessionId = typeof body.sessionId === "string" ? body.sessionId : "dashboard";
  if (!proposalId || !action) return Response.json({ error: "invalid request" }, { status: 400 });

  const [proposal] = await db.select().from(adaptationProposals).where(eq(adaptationProposals.id, proposalId)).limit(1);
  if (!proposal) return Response.json({ error: "not found" }, { status: 404 });
  if (proposal.status !== "pending") return Response.json({ error: "already resolved" }, { status: 409 });

  const [updated] = await db
    .update(adaptationProposals)
    .set({ status: action, studentNote: note, resolvedAt: new Date() })
    .where(eq(adaptationProposals.id, proposalId))
    .returning();

  if (action === "approved") {
    const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.studentId, proposal.studentId)).limit(1);
    const currentStrategy = (profile?.strategyJson as Record<string, unknown>) ?? {};
    const patch = (proposal.proposedPatchJson as Record<string, unknown>) ?? {};
    await db
      .update(learnerProfiles)
      .set({ strategyJson: { ...currentStrategy, ...patch }, updatedAt: new Date() })
      .where(eq(learnerProfiles.studentId, proposal.studentId));
  }

  await recordTelemetry(proposal.studentId, sessionId, `adaptation_${action}`, { proposalId, note });

  return Response.json({ proposal: updated });
}
