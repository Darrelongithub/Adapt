import { db } from "@/db";
import { students, adaptationProposals, telemetryEvents, retentionChecks, topics, quizAttempts } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { asMasteryMap, asModalityMap, getOrCreateProfile, getTopicsForSubject } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  const profile = await getOrCreateProfile(studentId);
  const topicRows = await getTopicsForSubject(student.subject);
  const masteryMap = asMasteryMap(profile.masteryJson);
  const modalityMap = asModalityMap(profile.modalityJson);

  const topicsWithMastery = topicRows.map((t) => ({
    ...t,
    mastery: masteryMap[String(t.id)]?.mastery ?? 0,
    attempts: masteryMap[String(t.id)]?.attempts ?? 0,
    correct: masteryMap[String(t.id)]?.correct ?? 0,
  }));

  const proposals = await db
    .select()
    .from(adaptationProposals)
    .where(eq(adaptationProposals.studentId, studentId))
    .orderBy(desc(adaptationProposals.createdAt));

  const telemetry = await db
    .select()
    .from(telemetryEvents)
    .where(eq(telemetryEvents.studentId, studentId))
    .orderBy(desc(telemetryEvents.createdAt))
    .limit(40);

  const retention = await db
    .select({
      id: retentionChecks.id,
      topicId: retentionChecks.topicId,
      dueAt: retentionChecks.dueAt,
      completedAt: retentionChecks.completedAt,
      topicTitle: topics.title,
    })
    .from(retentionChecks)
    .leftJoin(topics, eq(retentionChecks.topicId, topics.id))
    .where(eq(retentionChecks.studentId, studentId))
    .orderBy(desc(retentionChecks.createdAt));

  const totalAttempts = await db.select().from(quizAttempts).where(eq(quizAttempts.studentId, studentId));

  return Response.json({
    student,
    profile,
    topics: topicsWithMastery,
    modalityMap,
    proposals,
    telemetry,
    retention,
    stats: {
      totalAttempts: totalAttempts.length,
      totalCorrect: totalAttempts.filter((a) => a.correct).length,
    },
  });
}
