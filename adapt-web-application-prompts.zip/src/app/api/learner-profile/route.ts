import { db } from "@/db";
import { students } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getOrCreateProfile, getTopicsForSubject } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const studentId = Number(searchParams.get("studentId"));
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  const profile = await getOrCreateProfile(studentId);
  const topics = await getTopicsForSubject(student.subject);

  return Response.json({ student, profile, topics });
}
