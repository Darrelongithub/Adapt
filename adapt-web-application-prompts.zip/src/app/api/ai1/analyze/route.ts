import { db } from "@/db";
import { students, telemetryEvents, adaptationProposals } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { asMasteryMap, asModalityMap, getOrCreateProfile, getTopicLabelMap } from "@/lib/profile";
import { masterySummaryText, modalitySummaryText, weakestModality } from "@/lib/mastery";
import { generateJson, geminiEnabled } from "@/lib/gemini";
import { AI1_LEARNING_INTELLIGENCE_SYSTEM_PROMPT, buildAi1AnalysisPrompt, fillApprovalScript } from "@/lib/prompts";

export const dynamic = "force-dynamic";

type Ai1Result = {
  hasProposal: boolean;
  title: string;
  observations: string[];
  currentStrategyLabel: string;
  proposedStrategyLabel: string;
  proposedPatch: Record<string, unknown>;
  script: string;
};

const MODALITY_LABEL: Record<string, string> = {
  mcq: "standard multiple-choice questions",
  numeric: "numeric answer questions",
  teach_back: "teach-back explanations",
  worked_example: "step-by-step worked examples",
  visual: "visual/diagram-based questions",
};

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const studentId = Number(body.studentId);
  if (!studentId) return Response.json({ error: "studentId required" }, { status: 400 });

  const [student] = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!student) return Response.json({ error: "student not found" }, { status: 404 });

  // Don't pile up proposals: if one is already pending, return it.
  const pending = await db
    .select()
    .from(adaptationProposals)
    .where(eq(adaptationProposals.studentId, studentId))
    .orderBy(desc(adaptationProposals.createdAt));
  const existingPending = pending.find((p) => p.status === "pending");
  if (existingPending) return Response.json({ proposal: existingPending, alreadyPending: true });

  const profile = await getOrCreateProfile(studentId);
  const masteryMap = asMasteryMap(profile.masteryJson);
  const modalityMap = asModalityMap(profile.modalityJson);
  const topicLabels = await getTopicLabelMap(student.subject);

  const events = await db
    .select()
    .from(telemetryEvents)
    .where(eq(telemetryEvents.studentId, studentId))
    .orderBy(desc(telemetryEvents.createdAt))
    .limit(25);

  const totalAttempts = Object.values(modalityMap).reduce((a, v) => a + v.attempts, 0);
  if (totalAttempts < 3) {
    return Response.json({ proposal: null, reason: "not_enough_evidence" });
  }

  const masterySummary = masterySummaryText(masteryMap, topicLabels);
  const modalitySummary = modalitySummaryText(modalityMap);
  const recentTelemetry = events
    .slice()
    .reverse()
    .map((e) => `${e.createdAt.toISOString()} ${e.eventType} ${JSON.stringify(e.payloadJson)}`)
    .join("\n");
  const rejectedProposals = pending
    .filter((p) => p.status === "rejected")
    .map((p) => `- ${p.title}: ${p.currentStrategy} -> ${p.proposedStrategy}`)
    .join("\n") || "None.";

  let result: Ai1Result | null = null;

  if (geminiEnabled()) {
    try {
      result = await generateJson<Ai1Result>({
        system: AI1_LEARNING_INTELLIGENCE_SYSTEM_PROMPT,
        prompt: buildAi1AnalysisPrompt({
          studentName: student.name,
          subject: student.subject,
          masterySummary,
          modalitySummary,
          recentTelemetry,
          currentStrategy: JSON.stringify(profile.strategyJson),
          rejectedProposals,
        }),
      });
    } catch {
      result = null;
    }
  }

  if (!result) {
    // Deterministic heuristic fallback so the approval-gate flow always works
    // even with zero API keys configured.
    const weak = weakestModality(modalityMap);
    if (!weak) return Response.json({ proposal: null, reason: "not_enough_evidence" });
    const weakStat = modalityMap[weak];
    const accuracy = weakStat.attempts ? Math.round((weakStat.correct / weakStat.attempts) * 100) : 0;
    const strong = Object.entries(modalityMap)
      .filter(([k]) => k !== weak)
      .sort((a, b) => b[1].correct / Math.max(1, b[1].attempts) - a[1].correct / Math.max(1, a[1].attempts))[0];

    if (accuracy >= 60) return Response.json({ proposal: null, reason: "not_enough_evidence" });

    const observations = [
      `scored ${accuracy}% on ${MODALITY_LABEL[weak] ?? weak}`,
      `took longer than average on ${MODALITY_LABEL[weak] ?? weak}`,
      strong ? `did noticeably better on ${MODALITY_LABEL[strong[0]] ?? strong[0]}` : `answered confidently on other question types`,
      `this pattern repeated across multiple attempts`,
    ];
    const currentLabel = "a mixed explanation style";
    const proposedLabel = strong ? `leading with more ${MODALITY_LABEL[strong[0]] ?? strong[0]}` : "more worked examples before practice";

    result = {
      hasProposal: true,
      title: `Lean into ${strong ? MODALITY_LABEL[strong[0]] : "worked examples"}`,
      observations,
      currentStrategyLabel: currentLabel,
      proposedStrategyLabel: proposedLabel,
      proposedPatch: { workedExampleRatio: 0.55, explanationStyle: "detailed" },
      script: fillApprovalScript(observations, currentLabel, proposedLabel),
    };
  }

  if (!result.hasProposal) {
    return Response.json({ proposal: null, reason: "ai_declined" });
  }

  const [created] = await db
    .insert(adaptationProposals)
    .values({
      studentId,
      title: result.title,
      evidenceJson: result.observations,
      currentStrategy: result.currentStrategyLabel,
      proposedStrategy: result.proposedStrategyLabel,
      proposedPatchJson: result.proposedPatch,
      scriptText: result.script || fillApprovalScript(result.observations, result.currentStrategyLabel, result.proposedStrategyLabel),
      status: "pending",
    })
    .returning();

  return Response.json({ proposal: created });
}
