import { ensureSeeded } from "@/lib/seed";
import { getTopicsForSubject } from "@/lib/profile";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeeded();
  const { searchParams } = new URL(req.url);
  const subject = searchParams.get("subject");
  if (!subject) return Response.json({ error: "subject required" }, { status: 400 });
  const rows = await getTopicsForSubject(subject);
  return Response.json({ topics: rows });
}
