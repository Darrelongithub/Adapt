import type { ReactNode } from "react";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-3xl border border-beige-200 bg-white/80 shadow-[0_18px_50px_rgba(13,27,51,0.08)] backdrop-blur-sm ${className}`}
    >
      {children}
    </div>
  );
}

export function Badge({ children, tone = "blue" }: { children: ReactNode; tone?: "blue" | "beige" | "green" | "red" }) {
  const tones: Record<string, string> = {
    blue: "bg-sky-100 text-sky-700 border-sky-200",
    beige: "bg-beige-100 text-beige-600 border-beige-300",
    green: "bg-emerald-100 text-emerald-700 border-emerald-200",
    red: "bg-rose-100 text-rose-700 border-rose-200",
  };
  return (
    <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-medium ${tones[tone]}`}>
      {children}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const base = "inline-flex items-center justify-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50";
  const variants: Record<string, string> = {
    primary: "bg-ink-800 text-beige-50 hover:bg-ink-700 shadow-[0_10px_25px_rgba(13,27,51,0.25)]",
    secondary: "bg-sky-600 text-white hover:bg-sky-700 shadow-[0_10px_25px_rgba(38,85,193,0.25)]",
    ghost: "bg-transparent text-ink-700 border border-beige-300 hover:bg-beige-100",
    danger: "bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100",
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={`${base} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}

export function ProgressBar({ value, tone = "blue" }: { value: number; tone?: "blue" | "beige" }) {
  const pct = Math.max(0, Math.min(100, Math.round(value * 100)));
  const color = tone === "blue" ? "bg-sky-600" : "bg-beige-500";
  return (
    <div className="h-2.5 w-full overflow-hidden rounded-full bg-beige-100">
      <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function SectionLabel({ children }: { children: ReactNode }) {
  return <p className="text-xs font-semibold uppercase tracking-[0.18em] text-ink-400">{children}</p>;
}
