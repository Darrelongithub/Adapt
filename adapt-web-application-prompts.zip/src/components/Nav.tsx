"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useStudentSession } from "@/lib/useStudent";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/onboarding", label: "Onboarding" },
  { href: "/diagnostic", label: "Diagnostic" },
  { href: "/practice", label: "Practice" },
  { href: "/tutor", label: "Voice Tutor" },
  { href: "/dashboard", label: "Dashboard" },
];

export function Nav() {
  const pathname = usePathname();
  const { student } = useStudentSession();

  return (
    <header className="sticky top-0 z-40 border-b border-beige-200 bg-beige-50/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-ink-800 font-display text-sm font-bold text-beige-100">
            A
          </span>
          <span className="font-display text-lg font-semibold tracking-tight text-ink-900">ADAPT</span>
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {LINKS.map((link) => {
            const active = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition ${
                  active ? "bg-ink-800 text-beige-50" : "text-ink-600 hover:bg-beige-200/70"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
        <div className="flex items-center gap-2 text-xs text-ink-500">
          {student ? (
            <span className="rounded-full border border-sky-200 bg-sky-50 px-3 py-1.5 font-medium text-sky-700">
              {student.name} · {student.subject}
            </span>
          ) : (
            <Link href="/onboarding" className="rounded-full bg-sky-600 px-3.5 py-1.5 font-semibold text-white hover:bg-sky-700">
              Start demo
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
