// Minimal ambient types for the browser Web Speech API (not in the default
// TS DOM lib). Used for the local, zero-cost voice tutor experience.

export {};

declare global {
  interface SpeechRecognitionEventResultItem {
    transcript: string;
    confidence: number;
  }

  interface SpeechRecognitionAlternative {
    [index: number]: SpeechRecognitionEventResultItem;
    length: number;
  }

  interface SpeechRecognitionResultList {
    [index: number]: SpeechRecognitionAlternative;
    length: number;
  }

  interface SpeechRecognitionEvent extends Event {
    resultIndex: number;
    results: SpeechRecognitionResultList;
  }

  interface SpeechRecognitionErrorEvent extends Event {
    error: string;
  }

  interface SpeechRecognition extends EventTarget {
    lang: string;
    continuous: boolean;
    interimResults: boolean;
    maxAlternatives: number;
    onstart: (() => void) | null;
    onend: (() => void) | null;
    onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
    onresult: ((event: SpeechRecognitionEvent) => void) | null;
    start: () => void;
    stop: () => void;
    abort: () => void;
  }

  interface Window {
    SpeechRecognition?: new () => SpeechRecognition;
    webkitSpeechRecognition?: new () => SpeechRecognition;
  }
}
