// ---------------------------------------------------------------------------
// Minimal Gemini REST client (Google AI Studio free tier).
//
// Docs: https://ai.google.dev/api/generate-content
// Uses gemini-2.0-flash by default — fully covered by the Gemini free tier.
//
// If GEMINI_API_KEY is not configured, every call gracefully degrades to a
// deterministic local simulation so the whole ADAPT demo still works end to
// end on a judge's laptop with zero setup and zero cost.
// ---------------------------------------------------------------------------

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.0-flash";
const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

export function geminiEnabled() {
  return Boolean(process.env.GEMINI_API_KEY);
}

type GenerateArgs = {
  system: string;
  prompt: string;
  jsonSchema?: Record<string, unknown>;
  temperature?: number;
};

export async function generateText({ system, prompt, temperature = 0.6 }: GenerateArgs): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY not configured");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const res = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature, maxOutputTokens: 1024 },
      }),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      throw new Error(`Gemini error ${res.status}: ${errText}`);
    }
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "";
    return text.trim();
  } finally {
    clearTimeout(timeout);
  }
}

export async function generateJson<T>({ system, prompt, jsonSchema, temperature = 0.4 }: GenerateArgs): Promise<T> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY not configured");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);
  try {
    const res = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature,
          maxOutputTokens: 2048,
          response_mime_type: "application/json",
          ...(jsonSchema ? { response_schema: jsonSchema } : {}),
        },
      }),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => "");
      throw new Error(`Gemini error ${res.status}: ${errText}`);
    }
    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("") ?? "{}";
    return JSON.parse(text) as T;
  } finally {
    clearTimeout(timeout);
  }
}
