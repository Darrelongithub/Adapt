import { db } from "@/db";
import { topics, questions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { SUBJECTS } from "@/lib/seedData";

let seeded = false;

export async function ensureSeeded() {
  if (seeded) return;

  const existing = await db.select({ id: topics.id }).from(topics).limit(1);
  if (existing.length > 0) {
    seeded = true;
    return;
  }

  for (const subject of SUBJECTS) {
    for (const t of subject.topics) {
      const [row] = await db
        .insert(topics)
        .values({
          subject: subject.subject,
          slug: t.slug,
          title: t.title,
          description: t.description,
          orderIndex: t.orderIndex,
        })
        .onConflictDoNothing({ target: topics.slug })
        .returning({ id: topics.id });

      let topicId = row?.id;
      if (!topicId) {
        const found = await db.select({ id: topics.id }).from(topics).where(eq(topics.slug, t.slug)).limit(1);
        topicId = found[0]?.id;
      }
      if (!topicId) continue;

      for (const q of t.questions) {
        await db.insert(questions).values({
          topicId,
          kind: q.kind,
          type: q.type,
          prompt: q.prompt,
          payloadJson: q.payload,
          difficulty: q.difficulty,
        });
      }
    }
  }

  seeded = true;
}

export const SUBJECT_NAMES = SUBJECTS.map((s) => s.subject);
