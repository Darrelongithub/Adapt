"use client";

import { useCallback, useEffect, useState } from "react";

export type StudentSession = {
  studentId: number;
  name: string;
  subject: string;
};

const STORAGE_KEY = "adapt.student";
const SESSION_KEY = "adapt.sessionId";

function randomId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `sess-${Math.random().toString(36).slice(2)}-${Date.now()}`;
}

export function useStudentSession() {
  const [student, setStudentState] = useState<StudentSession | null>(null);
  const [sessionId, setSessionId] = useState<string>("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setStudentState(JSON.parse(raw));
    } catch {
      // ignore
    }
    let sid = sessionStorage.getItem(SESSION_KEY);
    if (!sid) {
      sid = randomId();
      sessionStorage.setItem(SESSION_KEY, sid);
    }
    setSessionId(sid);
    setReady(true);
  }, []);

  const setStudent = useCallback((s: StudentSession) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    setStudentState(s);
  }, []);

  const clearStudent = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setStudentState(null);
  }, []);

  return { student, setStudent, clearStudent, sessionId, ready };
}
