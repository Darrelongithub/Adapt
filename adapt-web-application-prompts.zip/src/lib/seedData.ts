// Seed curriculum content: 2 subjects x 4 topics x (3 diagnostic + 4 practice)
// questions. Mixed modalities so the modality-affinity engine has signal to
// work with: mcq (text), visual, worked_example, teach_back, numeric.

export type SeedQuestion = {
  kind: "diagnostic" | "practice";
  type: "mcq" | "numeric" | "teach_back" | "worked_example" | "visual";
  prompt: string;
  payload: Record<string, unknown>;
  difficulty: number;
};

export type SeedTopic = {
  slug: string;
  title: string;
  description: string;
  orderIndex: number;
  questions: SeedQuestion[];
};

export type SeedSubject = {
  subject: string;
  topics: SeedTopic[];
};

export const SUBJECTS: SeedSubject[] = [
  {
    subject: "Algebra Foundations",
    topics: [
      {
        slug: "linear-equations",
        title: "Linear Equations",
        description: "Solving and interpreting equations of the form ax + b = c.",
        orderIndex: 1,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "Solve for x: 3x + 5 = 20",
            payload: { choices: ["3", "5", "7.5", "15"], correctIndex: 1, explanation: "3x = 15, so x = 5." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "worked_example",
            prompt: "Follow the worked steps, then pick the correct final value of x: 2(x - 3) = 10",
            payload: {
              steps: ["Distribute: 2x - 6 = 10", "Add 6 to both sides: 2x = 16", "Divide by 2: x = 8"],
              choices: ["5", "8", "11", "2"],
              correctIndex: 1,
              explanation: "2x = 16 so x = 8.",
            },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "In your own words, explain how you would solve any equation like ax + b = c for x.",
            payload: { rubric: "Mentions isolating the variable, inverse operations, keeping both sides balanced." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "Solve for x: 4x - 7 = 9",
            payload: { correctValue: 4, tolerance: 0.01, explanation: "4x = 16, x = 4." },
            difficulty: 1,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Which value of x satisfies 5(x + 1) = 25?",
            payload: { choices: ["3", "4", "5", "6"], correctIndex: 1, explanation: "x + 1 = 5, x = 4." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "A balance scale shows 2x on the left and 14 on the right, perfectly balanced. What is x?",
            payload: {
              diagram: "⚖️  [ x | x ]  ====  [ 14 ]",
              choices: ["5", "6", "7", "8"],
              correctIndex: 2,
              explanation: "2x = 14 so x = 7.",
            },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "Using the same method, solve: 3(x + 2) - 4 = 11",
            payload: {
              steps: ["Distribute: 3x + 6 - 4 = 11", "Simplify: 3x + 2 = 11", "Subtract 2: 3x = 9", "Divide: x = 3"],
              choices: ["2", "3", "4", "5"],
              correctIndex: 1,
              explanation: "3x = 9 so x = 3.",
            },
            difficulty: 3,
          },
        ],
      },
      {
        slug: "exponents",
        title: "Exponents & Powers",
        description: "Rules for multiplying, dividing, and simplifying powers.",
        orderIndex: 2,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "Simplify: x^3 * x^4",
            payload: { choices: ["x^7", "x^12", "x^1", "2x^7"], correctIndex: 0, explanation: "Add exponents: 3+4=7." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "numeric",
            prompt: "What is 2^5?",
            payload: { correctValue: 32, tolerance: 0, explanation: "2*2*2*2*2 = 32." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain why x^0 = 1 for any nonzero x, as if teaching a friend.",
            payload: { rubric: "Mentions pattern of dividing powers, e.g. x^1/x^1 = x^0 = 1." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Simplify: (x^2)^3",
            payload: { choices: ["x^5", "x^6", "x^8", "x^9"], correctIndex: 1, explanation: "Multiply exponents: 2*3=6." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "Simplify x^8 / x^3 using the division rule.",
            payload: {
              steps: ["Subtract exponents: 8 - 3 = 5"],
              choices: ["x^5", "x^11", "x^2", "x^24"],
              correctIndex: 0,
              explanation: "x^8/x^3 = x^5.",
            },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "A growth chart doubles every step starting at 3 (3, 6, 12, 24...). What power of 2 multiplies step 1 to get step 4?",
            payload: {
              diagram: "3 → 6 → 12 → 24  (x2 each step)",
              choices: ["2^1", "2^2", "2^3", "2^4"],
              correctIndex: 2,
              explanation: "3 steps of doubling = 2^3 = 8, and 3*8=24.",
            },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "Evaluate 4^-2 as a decimal.",
            payload: { correctValue: 0.0625, tolerance: 0.001, explanation: "4^-2 = 1/16 = 0.0625." },
            difficulty: 4,
          },
        ],
      },
      {
        slug: "factoring",
        title: "Factoring Quadratics",
        description: "Breaking quadratic expressions into products of binomials.",
        orderIndex: 3,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "Factor: x^2 + 5x + 6",
            payload: { choices: ["(x+2)(x+3)", "(x+1)(x+6)", "(x-2)(x-3)", "(x+6)(x-1)"], correctIndex: 0, explanation: "2*3=6 and 2+3=5." },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "worked_example",
            prompt: "Factor x^2 - 9 following the difference-of-squares pattern.",
            payload: {
              steps: ["Recognize a^2 - b^2 pattern: x^2 - 3^2", "Apply (a-b)(a+b)"],
              choices: ["(x-3)(x+3)", "(x-9)(x+1)", "(x-3)^2", "(x+3)^2"],
              correctIndex: 0,
              explanation: "x^2-9 = (x-3)(x+3).",
            },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain the strategy you use to factor a quadratic like x^2 + bx + c.",
            payload: { rubric: "Mentions finding two numbers that multiply to c and add to b." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Factor: x^2 - 7x + 12",
            payload: { choices: ["(x-3)(x-4)", "(x+3)(x+4)", "(x-2)(x-6)", "(x-1)(x-12)"], correctIndex: 0, explanation: "-3*-4=12, -3-4=-7." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "For x^2 - x - 6 = 0, what is the larger root?",
            payload: { correctValue: 3, tolerance: 0, explanation: "(x-3)(x+2)=0 so x=3 or x=-2." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "An area model splits a square of side (x+2) into 4 regions: x^2, 2x, 2x, 4. What is the total area expression?",
            payload: {
              diagram: "[x^2 | 2x]\n[2x  | 4 ]",
              choices: ["x^2+4x+4", "x^2+2x+4", "x^2+4", "x^2+4x+2"],
              correctIndex: 0,
              explanation: "(x+2)^2 = x^2+4x+4.",
            },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "Factor 2x^2 + 7x + 3 by grouping.",
            payload: {
              steps: ["Find ac=6, need two numbers multiplying to 6 and adding to 7: 6 and 1", "Split: 2x^2+6x+x+3", "Group: 2x(x+3)+1(x+3)"],
              choices: ["(2x+1)(x+3)", "(2x+3)(x+1)", "(x+6)(2x+1)", "(2x+7)(x+... )"],
              correctIndex: 0,
              explanation: "2x(x+3)+1(x+3) = (2x+1)(x+3).",
            },
            difficulty: 4,
          },
        ],
      },
      {
        slug: "functions",
        title: "Intro to Functions",
        description: "Function notation, domain/range, and reading graphs.",
        orderIndex: 4,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "If f(x) = 2x + 1, what is f(4)?",
            payload: { choices: ["7", "8", "9", "10"], correctIndex: 2, explanation: "2*4+1=9." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "visual",
            prompt: "A graph is a straight line passing through (0,2) and (2,6). What is the slope?",
            payload: {
              diagram: "(0,2) ---line--- (2,6)",
              choices: ["1", "2", "3", "4"],
              correctIndex: 1,
              explanation: "slope = (6-2)/(2-0) = 2.",
            },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain what makes a relation a 'function' in your own words.",
            payload: { rubric: "Mentions each input maps to exactly one output." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Given g(x) = x^2 - 1, what is g(-3)?",
            payload: { choices: ["8", "9", "-8", "10"], correctIndex: 0, explanation: "(-3)^2-1=9-1=8." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "If h(x) = 3x - 2 and h(x) = 10, what is x?",
            payload: { correctValue: 4, tolerance: 0, explanation: "3x=12, x=4." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "Find the domain restriction for f(x) = 1/(x-5).",
            payload: {
              steps: ["Denominator cannot be 0", "x - 5 ≠ 0"],
              choices: ["x ≠ 5", "x ≠ -5", "x ≠ 0", "all real numbers"],
              correctIndex: 0,
              explanation: "x cannot equal 5.",
            },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "A parabola opens upward with vertex at (1,-4). Where does it cross y when x=1?",
            payload: {
              diagram: "vertex (1,-4), opens up ⌣",
              choices: ["-4", "0", "1", "4"],
              correctIndex: 0,
              explanation: "At the vertex x=1, y=-4.",
            },
            difficulty: 3,
          },
        ],
      },
    ],
  },
  {
    subject: "Cell Biology",
    topics: [
      {
        slug: "cell-structure",
        title: "Cell Structure & Organelles",
        description: "Roles of the nucleus, mitochondria, ribosomes, and membranes.",
        orderIndex: 1,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "Which organelle is the main site of ATP production?",
            payload: { choices: ["Nucleus", "Mitochondria", "Golgi apparatus", "Ribosome"], correctIndex: 1, explanation: "Mitochondria produce ATP via respiration." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "visual",
            prompt: "In the labeled cell diagram, the structure covered in dots (rough texture) studded along membranes is most likely which organelle?",
            payload: {
              diagram: "[Nucleus]--[ER with dots]--[Ribosomes dotted along ER]",
              choices: ["Smooth ER", "Rough ER", "Lysosome", "Vacuole"],
              correctIndex: 1,
              explanation: "Rough ER is studded with ribosomes.",
            },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain the role of the nucleus as if teaching a classmate.",
            payload: { rubric: "Mentions storing DNA/genetic instructions and controlling cell activity." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Which organelle packages and ships proteins out of the cell?",
            payload: { choices: ["Golgi apparatus", "Mitochondria", "Nucleolus", "Cytoskeleton"], correctIndex: 0, explanation: "The Golgi apparatus packages/modifies proteins." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "Trace a protein's path: it is made, then modified, then shipped. Pick the correct order of organelles.",
            payload: {
              steps: ["Made at ribosome", "Modified in rough ER then Golgi", "Shipped via vesicle"],
              choices: ["Ribosome → Rough ER → Golgi → Vesicle", "Golgi → Ribosome → ER", "Nucleus → Ribosome → Vacuole", "Mitochondria → Golgi"],
              correctIndex: 0,
              explanation: "Ribosome -> ER -> Golgi -> vesicle is the secretory pathway.",
            },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "If a cell has 12 mitochondria and energy demand doubles, triggering proportional mitochondrial growth, how many mitochondria would you expect?",
            payload: { correctValue: 24, tolerance: 0, explanation: "Doubling 12 gives 24." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "teach_back",
            prompt: "Explain why the cell membrane is described as 'selectively permeable'.",
            payload: { rubric: "Mentions that it allows some molecules through and blocks others." },
            difficulty: 3,
          },
        ],
      },
      {
        slug: "membrane-transport",
        title: "Membrane Transport",
        description: "Diffusion, osmosis, and active vs passive transport.",
        orderIndex: 2,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "Movement of water across a membrane from low to high solute concentration is called:",
            payload: { choices: ["Diffusion", "Osmosis", "Active transport", "Endocytosis"], correctIndex: 1, explanation: "Osmosis is water movement toward higher solute concentration." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "visual",
            prompt: "A cell placed in a hypertonic solution is shown shriveling in the diagram. What is happening?",
            payload: {
              diagram: "Cell (round) -> hypertonic solution -> Cell (shriveled)",
              choices: ["Water leaving the cell", "Water entering the cell", "Salt leaving the cell", "No movement"],
              correctIndex: 0,
              explanation: "In hypertonic solution, water leaves the cell, causing shriveling.",
            },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain the difference between passive and active transport.",
            payload: { rubric: "Mentions passive needs no energy (down gradient), active needs ATP (against gradient)." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "The sodium-potassium pump is an example of:",
            payload: { choices: ["Facilitated diffusion", "Active transport", "Osmosis", "Simple diffusion"], correctIndex: 1, explanation: "It uses ATP to move ions against their gradient." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "worked_example",
            prompt: "A red blood cell is placed in pure water (hypotonic). Predict what happens step by step.",
            payload: {
              steps: ["Water concentration is higher outside the cell", "Water moves into the cell by osmosis", "Cell may swell or burst (lyse)"],
              choices: ["Cell shrinks", "Cell swells/bursts", "No change", "Cell divides"],
              correctIndex: 1,
              explanation: "Hypotonic solution causes water influx and swelling.",
            },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "If a cell starts with 100 solute particles inside and diffusion equalizes concentration with 300 outside across an equal volume, roughly what fraction of total particles end up inside at equilibrium (as a decimal)?",
            payload: { correctValue: 0.5, tolerance: 0.05, explanation: "At equilibrium concentration equalizes, so roughly half the combined total on each side (simplified model)." },
            difficulty: 4,
          },
          {
            kind: "practice",
            type: "teach_back",
            prompt: "Explain what 'facilitated diffusion' means and how it differs from simple diffusion.",
            payload: { rubric: "Mentions use of channel/carrier proteins, still passive, no ATP required." },
            difficulty: 3,
          },
        ],
      },
      {
        slug: "cellular-respiration",
        title: "Cellular Respiration",
        description: "Glycolysis, the Krebs cycle, and the electron transport chain.",
        orderIndex: 3,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "What is the main product of cellular respiration that cells use for energy?",
            payload: { choices: ["Glucose", "ATP", "Oxygen", "CO2"], correctIndex: 1, explanation: "ATP is the usable energy currency." },
            difficulty: 1,
          },
          {
            kind: "diagnostic",
            type: "worked_example",
            prompt: "Follow the stages in order: glycolysis happens in the cytoplasm, then pyruvate enters the mitochondria for the Krebs cycle, then electrons flow through the ETC. Which stage produces the MOST ATP overall?",
            payload: {
              steps: ["Glycolysis: ~2 ATP", "Krebs cycle: ~2 ATP", "Electron transport chain: ~26-28 ATP"],
              choices: ["Glycolysis", "Krebs cycle", "Electron transport chain", "They are equal"],
              correctIndex: 2,
              explanation: "The ETC produces the majority of ATP via oxidative phosphorylation.",
            },
            difficulty: 3,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain in your own words why we need to breathe oxygen for cellular respiration.",
            payload: { rubric: "Mentions oxygen as final electron acceptor in the electron transport chain." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Where does the Krebs cycle take place?",
            payload: { choices: ["Cytoplasm", "Mitochondrial matrix", "Nucleus", "Cell membrane"], correctIndex: 1, explanation: "Krebs cycle occurs in the mitochondrial matrix." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "If glycolysis nets 2 ATP and the Krebs cycle nets 2 ATP per glucose, and the ETC nets 28 ATP, what is the approximate total ATP per glucose?",
            payload: { correctValue: 32, tolerance: 2, explanation: "2+2+28 ≈ 32 ATP total." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "In the ETC diagram, electrons flow 'downhill' releasing energy used to pump H+ ions, building a gradient that spins ATP synthase. What directly powers ATP synthase?",
            payload: {
              diagram: "e- flow -> H+ pumped out -> gradient -> ATP synthase spins -> ATP",
              choices: ["Electron flow directly", "The H+ gradient", "Oxygen directly", "Glucose directly"],
              correctIndex: 1,
              explanation: "The proton (H+) gradient drives ATP synthase (chemiosmosis).",
            },
            difficulty: 4,
          },
          {
            kind: "practice",
            type: "teach_back",
            prompt: "Explain what happens during fermentation when oxygen is not available.",
            payload: { rubric: "Mentions pyruvate converts to lactate or ethanol/CO2, regenerating NAD+ without oxygen." },
            difficulty: 4,
          },
        ],
      },
      {
        slug: "dna-replication",
        title: "DNA Replication",
        description: "How the double helix copies itself accurately before cell division.",
        orderIndex: 4,
        questions: [
          {
            kind: "diagnostic",
            type: "mcq",
            prompt: "DNA replication is described as 'semi-conservative' because:",
            payload: { choices: ["Both strands are destroyed", "Each new molecule has one old + one new strand", "Only RNA is produced", "No template is used"], correctIndex: 1, explanation: "Each daughter DNA keeps one original strand." },
            difficulty: 2,
          },
          {
            kind: "diagnostic",
            type: "worked_example",
            prompt: "Follow the steps of replication in order and identify what the enzyme helicase does.",
            payload: {
              steps: ["Helicase unwinds and separates the two strands", "Primase lays down RNA primers", "DNA polymerase adds new complementary bases", "Ligase seals fragments"],
              choices: ["Unwinds the double helix", "Adds new bases", "Seals gaps", "Lays down primers"],
              correctIndex: 0,
              explanation: "Helicase unwinds the double helix at the replication fork.",
            },
            difficulty: 3,
          },
          {
            kind: "diagnostic",
            type: "teach_back",
            prompt: "Explain why DNA replication needs to be so accurate.",
            payload: { rubric: "Mentions preventing mutations and ensuring correct genetic information passes to daughter cells." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "mcq",
            prompt: "Which enzyme adds new nucleotides to a growing DNA strand?",
            payload: { choices: ["Helicase", "DNA polymerase", "Ligase", "Primase"], correctIndex: 1, explanation: "DNA polymerase synthesizes the new strand." },
            difficulty: 2,
          },
          {
            kind: "practice",
            type: "numeric",
            prompt: "A DNA molecule has 3.2 billion base pairs. After one round of semi-conservative replication, how many total base pairs exist across both resulting molecules (in billions)?",
            payload: { correctValue: 6.4, tolerance: 0.1, explanation: "Two molecules of 3.2 billion bp each = 6.4 billion total." },
            difficulty: 3,
          },
          {
            kind: "practice",
            type: "visual",
            prompt: "On the replication fork diagram, one new strand is made continuously (leading) and one in fragments (lagging). What are the lagging-strand fragments called?",
            payload: {
              diagram: "Fork: leading strand (smooth) | lagging strand (choppy fragments)",
              choices: ["Primers", "Okazaki fragments", "Telomeres", "Codons"],
              correctIndex: 1,
              explanation: "Lagging strand fragments are Okazaki fragments.",
            },
            difficulty: 4,
          },
          {
            kind: "practice",
            type: "teach_back",
            prompt: "Explain why the lagging strand is synthesized in fragments instead of continuously.",
            payload: { rubric: "Mentions DNA polymerase only synthesizes 5' to 3', so it works away from the fork in pieces on one strand." },
            difficulty: 4,
          },
        ],
      },
    ],
  },
];
