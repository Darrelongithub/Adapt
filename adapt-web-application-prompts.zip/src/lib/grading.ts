import { generateJson, geminiEnabled } from "@/lib/gemini";
import { TEACH_BACK_GRADER_SYSTEM_PROMPT } from "@/lib/prompts";

export type QuestionRow = {
  id: number;
  type: string;
  prompt: string;
  payloadJson: Record<string, unknown>;
};

export type GradeResult = {
  correct: boolean;
  score: number; // 0..1
  explanation: string;
  feedback?: string;
};

export async function gradeAnswer(question: QuestionRow, finalAnswer: string): Promise<GradeResult> {
  const payload = question.payloadJson;

  if (question.type === "mcq" || question.type === "worked_example" || question.type === "visual") {
    const correctIndex = Number(payload.correctIndex);
    const given = Number(finalAnswer);
    const correct = given === correctIndex;
    return {
      correct,
      score: correct ? 1 : 0,
      explanation: String(payload.explanation ?? ""),
    };
  }

  if (question.type === "numeric") {
    const correctValue = Number(payload.correctValue);
    const tolerance = Number(payload.tolerance ?? 0);
    const given = Number(finalAnswer);
    const correct = Number.isFinite(given) && Math.abs(given - correctValue) <= tolerance + 1e-9;
    return {
      correct,
      score: correct ? 1 : 0,
      explanation: String(payload.explanation ?? ""),
    };
  }

  if (question.type === "teach_back") {
    const rubric = String(payload.rubric ?? "");
    if (geminiEnabled()) {
      try {
        const result = await generateJson<{ score: number; feedback: string; misconceptions: string[] }>({
          system: TEACH_BACK_GRADER_SYSTEM_PROMPT,
          prompt: `Question: ${question.prompt}\nRubric guidance: ${rubric}\nStudent's answer: "${finalAnswer}"`,
        });
        return {
          correct: result.score >= 0.6,
          score: result.score,
          explanation: rubric,
          feedback: result.feedback,
        };
      } catch {
        // fall through to heuristic
      }
    }
    // Deterministic heuristic fallback: keyword overlap with rubric.
    const rubricWords = rubric.toLowerCase().match(/[a-z]{4,}/g) ?? [];
    const answerLower = finalAnswer.toLowerCase();
    const hits = rubricWords.filter((w) => answerLower.includes(w));
    const score = rubricWords.length ? Math.min(1, hits.length / Math.max(2, rubricWords.length * 0.4)) : finalAnswer.length > 20 ? 0.6 : 0.2;
    return {
      correct: score >= 0.6,
      score,
      explanation: rubric,
      feedback:
        score >= 0.6
          ? "Nice explanation — you hit the key idea."
          : "You're on the right track, but try to mention the core mechanism more directly.",
    };
  }

  return { correct: false, score: 0, explanation: "" };
}
