// Simplified Bayesian Knowledge Tracing + modality-affinity tracking.

export type TopicMastery = {
  mastery: number; // 0..1
  attempts: number;
  correct: number;
  lastPracticed: string | null;
};

export type MasteryMap = Record<string, TopicMastery>;

export type ModalityStat = {
  attempts: number;
  correct: number;
  avgMs: number;
};

export type ModalityMap = Record<string, ModalityStat>;

const P_TRANSIT = 0.15; // chance of learning after an attempt
const P_SLIP = 0.1; // chance of mistake despite knowing
const P_GUESS = 0.22; // chance of correct guess despite not knowing

export function bktUpdate(prior: number, correct: boolean): number {
  const pCorrectGivenKnow = 1 - P_SLIP;
  const pCorrectGivenNotKnow = P_GUESS;

  const pEvidence = correct
    ? prior * pCorrectGivenKnow + (1 - prior) * pCorrectGivenNotKnow
    : prior * P_SLIP + (1 - prior) * (1 - P_GUESS);

  const pKnowGivenEvidence = correct
    ? (prior * pCorrectGivenKnow) / Math.max(pEvidence, 1e-6)
    : (prior * P_SLIP) / Math.max(pEvidence, 1e-6);

  const posterior = pKnowGivenEvidence + (1 - pKnowGivenEvidence) * P_TRANSIT;
  return Math.min(0.99, Math.max(0.01, posterior));
}

export function updateTopicMastery(map: MasteryMap, topicKey: string, correct: boolean): MasteryMap {
  const prev = map[topicKey] ?? { mastery: 0.3, attempts: 0, correct: 0, lastPracticed: null };
  const nextMastery = bktUpdate(prev.mastery, correct);
  return {
    ...map,
    [topicKey]: {
      mastery: nextMastery,
      attempts: prev.attempts + 1,
      correct: prev.correct + (correct ? 1 : 0),
      lastPracticed: new Date().toISOString(),
    },
  };
}

export function updateModalityStat(map: ModalityMap, type: string, correct: boolean, timeSpentMs: number): ModalityMap {
  const prev = map[type] ?? { attempts: 0, correct: 0, avgMs: 0 };
  const attempts = prev.attempts + 1;
  const avgMs = Math.round((prev.avgMs * prev.attempts + timeSpentMs) / attempts);
  return {
    ...map,
    [type]: {
      attempts,
      correct: prev.correct + (correct ? 1 : 0),
      avgMs,
    },
  };
}

export function masterySummaryText(map: MasteryMap, topicLabels: Record<string, string>): string {
  const lines = Object.entries(map).map(([key, v]) => {
    const label = topicLabels[key] ?? key;
    const pct = Math.round(v.mastery * 100);
    return `- ${label}: ${pct}% mastery (${v.correct}/${v.attempts} correct)`;
  });
  return lines.length ? lines.join("\n") : "No practice data yet.";
}

export function modalitySummaryText(map: ModalityMap): string {
  const lines = Object.entries(map).map(([type, v]) => {
    const accuracy = v.attempts ? Math.round((v.correct / v.attempts) * 100) : 0;
    return `- ${type}: ${accuracy}% accuracy over ${v.attempts} attempts, avg ${Math.round(v.avgMs / 1000)}s`;
  });
  return lines.length ? lines.join("\n") : "No modality data yet.";
}

export function weakestModality(map: ModalityMap): string | null {
  let worst: string | null = null;
  let worstScore = Infinity;
  for (const [type, v] of Object.entries(map)) {
    if (v.attempts < 2) continue;
    const score = v.correct / v.attempts;
    if (score < worstScore) {
      worstScore = score;
      worst = type;
    }
  }
  return worst;
}

export function pickNextDifficulty(mastery: number): number {
  if (mastery < 0.35) return 1;
  if (mastery < 0.55) return 2;
  if (mastery < 0.75) return 3;
  return 4;
}
