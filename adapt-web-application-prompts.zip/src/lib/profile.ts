import { db } from "@/db";
import { learnerProfiles, topics, telemetryEvents } from "@/db/schema";
import { eq, asc } from "drizzle-orm";
import type { MasteryMap, ModalityMap } from "@/lib/mastery";

export type StrategyJson = {
  explanationStyle: "concise" | "balanced" | "detailed";
  workedExampleRatio: number;
  hintAggressiveness: "gentle" | "standard" | "direct";
  preferredPace: "slower" | "standard" | "faster";
};

export const DEFAULT_STRATEGY: StrategyJson = {
  explanationStyle: "balanced",
  workedExampleRatio: 0.3,
  hintAggressiveness: "standard",
  preferredPace: "standard",
};

export async function getOrCreateProfile(studentId: number) {
  const existing = await db.select().from(learnerProfiles).where(eq(learnerProfiles.studentId, studentId)).limit(1);
  if (existing[0]) return existing[0];

  const [created] = await db
    .insert(learnerProfiles)
    .values({
      studentId,
      masteryJson: {},
      modalityJson: {},
      strengthsJson: [],
      gapsJson: [],
      strategyJson: DEFAULT_STRATEGY,
      narrative: "",
    })
    .returning();
  return created;
}

export async function getTopicsForSubject(subject: string) {
  return db.select().from(topics).where(eq(topics.subject, subject)).orderBy(asc(topics.orderIndex));
}

export async function getTopicLabelMap(subject: string): Promise<Record<string, string>> {
  const rows = await getTopicsForSubject(subject);
  const map: Record<string, string> = {};
  for (const t of rows) map[String(t.id)] = t.title;
  return map;
}

export async function recordTelemetry(studentId: number, sessionId: string, eventType: string, payload: Record<string, unknown>) {
  await db.insert(telemetryEvents).values({ studentId, sessionId, eventType, payloadJson: payload });
}

export function asMasteryMap(value: unknown): MasteryMap {
  return (value as MasteryMap) ?? {};
}

export function asModalityMap(value: unknown): ModalityMap {
  return (value as ModalityMap) ?? {};
}
