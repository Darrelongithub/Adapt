import { XMLParser } from "fast-xml-parser";

export type ResourceItem = {
  source: "openalex" | "arxiv" | "openlibrary" | "youtube";
  title: string;
  url: string;
  metadata: Record<string, unknown>;
};

function withTimeout(ms: number) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), ms);
  return { signal: controller.signal, clear: () => clearTimeout(id) };
}

async function safeFetchJson(url: string, ms = 6000): Promise<unknown | null> {
  const { signal, clear } = withTimeout(ms);
  try {
    const res = await fetch(url, { signal, headers: { "User-Agent": "ADAPT-demo/1.0 (education)" } });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  } finally {
    clear();
  }
}

async function safeFetchText(url: string, ms = 6000): Promise<string | null> {
  const { signal, clear } = withTimeout(ms);
  try {
    const res = await fetch(url, { signal });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  } finally {
    clear();
  }
}

export async function searchOpenAlex(query: string): Promise<ResourceItem[]> {
  const url = `https://api.openalex.org/works?search=${encodeURIComponent(query)}&per_page=3&sort=relevance_score:desc`;
  const data = (await safeFetchJson(url)) as { results?: Array<Record<string, unknown>> } | null;
  if (!data?.results) return [];
  return data.results.map((r) => ({
    source: "openalex" as const,
    title: String(r.title ?? r.display_name ?? "Untitled work"),
    url: String((r as { doi?: string; id?: string }).doi ?? (r as { id?: string }).id ?? ""),
    metadata: { year: (r as { publication_year?: number }).publication_year },
  }));
}

export async function searchArxiv(query: string): Promise<ResourceItem[]> {
  const url = `https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(query)}&start=0&max_results=3`;
  const xml = await safeFetchText(url);
  if (!xml) return [];
  try {
    const parser = new XMLParser();
    const parsed = parser.parse(xml);
    const entries = parsed?.feed?.entry;
    const list = Array.isArray(entries) ? entries : entries ? [entries] : [];
    return list.map((e: Record<string, unknown>) => ({
      source: "arxiv" as const,
      title: String(e.title ?? "Untitled paper").replace(/\s+/g, " ").trim(),
      url: String(e.id ?? ""),
      metadata: { published: e.published },
    }));
  } catch {
    return [];
  }
}

export async function searchOpenLibrary(query: string): Promise<ResourceItem[]> {
  const url = `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=3`;
  const data = (await safeFetchJson(url)) as { docs?: Array<Record<string, unknown>> } | null;
  if (!data?.docs) return [];
  return data.docs.map((d) => ({
    source: "openlibrary" as const,
    title: String(d.title ?? "Untitled book"),
    url: d.key ? `https://openlibrary.org${d.key}` : "",
    metadata: { author: (d.author_name as string[] | undefined)?.[0], year: d.first_publish_year },
  }));
}

export async function searchYouTube(query: string): Promise<ResourceItem[]> {
  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) return [];
  const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=3&q=${encodeURIComponent(
    query,
  )}&key=${apiKey}`;
  const data = (await safeFetchJson(url)) as { items?: Array<Record<string, unknown>> } | null;
  if (!data?.items) return [];
  return data.items.map((item) => {
    const id = item.id as { videoId?: string };
    const snippet = item.snippet as { title?: string; channelTitle?: string };
    return {
      source: "youtube" as const,
      title: String(snippet?.title ?? "Untitled video"),
      url: id?.videoId ? `https://www.youtube.com/watch?v=${id.videoId}` : "",
      metadata: { channel: snippet?.channelTitle },
    };
  });
}

export async function searchAllResources(query: string): Promise<ResourceItem[]> {
  const [openalex, arxiv, openlibrary, youtube] = await Promise.all([
    searchOpenAlex(query).catch(() => []),
    searchArxiv(query).catch(() => []),
    searchOpenLibrary(query).catch(() => []),
    searchYouTube(query).catch(() => []),
  ]);
  return [...openalex, ...arxiv, ...openlibrary, ...youtube].filter((r) => r.url);
}
